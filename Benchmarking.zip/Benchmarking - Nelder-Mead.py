# -*- coding: utf-8 -*-
"""
Created on Mon Nov  3 09:49:18 2025

@author: gh00616
"""

#P1

import numpy as np
from scipy.optimize import minimize
from pyomo.environ import ConcreteModel, Var, Reals, Objective, Constraint, value

# ============================================================
# 1. Define the Pyomo model
# ============================================================
m = ConcreteModel()

# Decision variables
m.x1 = Var(initialize=0.0)
m.x2 = Var(bounds=(-2.0, None), initialize=0.0)

# Objective: (x1 - 1)^2 + (x2 - 3)^2 + x1^2 + (x2^2)^2
m.obj = Objective(expr=(m.x1 - 1)**2 + (m.x2 - 3)**2 + m.x1**2 + (m.x2**2)**2)

# Equality constraint: 2x1 + x2 + 10 - x1^2 - x2^2 = 0
m.c1 = Constraint(expr=2*m.x1 + m.x2 + 10.0 - m.x1**2 - m.x2**2 == 0)

# ============================================================
# 2. Define helper functions (Pyomo ↔ NumPy bridge)
# ============================================================
var_list = [m.x1, m.x2]

def get_vector():
    """Extract NumPy vector of variable values."""
    return np.array([value(v) for v in var_list])

def set_vector(v):
    """Assign NumPy vector values to Pyomo variables."""
    for i, var in enumerate(var_list):
        var.value = float(v[i])

def raw_objective(v):
    """Evaluate the original Pyomo objective."""
    set_vector(v)
    return value(m.obj.expr)

def equality_constraint(v):
    """Compute equality constraint residual h(x)."""
    set_vector(v)
    return value(m.c1.body)

def penalized_objective(v, rho=1e4):
    """Quadratic penalty formulation for equality constraint."""
    f = raw_objective(v)
    h = equality_constraint(v)
    return f + rho * (h**2)


# ============================================================
# 3. Define initial guess and bounds
# ============================================================
x0 = get_vector()

# Replace infinite bounds with large finite numbers
lower = np.array([-10.0, -2.0])
upper = np.array([10.0, 10.0])
bounds = list(zip(lower, upper))


# ============================================================
# 4. Solve using Nelder–Mead
# ============================================================
result = minimize(
    lambda v: penalized_objective(v, rho=1e4),
    x0,
    method='Nelder-Mead',
    bounds=bounds,
    options={'maxiter': 2000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
)


# ============================================================
# 5. Print results
# ============================================================
print("\n--- Nelder–Mead (Penalty) Results ---")
print(f"Success: {result.success}")
print(f"Message: {result.message}")
print(f"Objective (penalized): {result.fun:.6f}")
print(f"Function evaluations: {result.nfev}")
print(f"Best solution (x*): {result.x}")

# Push the result back to the Pyomo model
set_vector(result.x)

# Evaluate constraint residual and raw objective
f_raw = raw_objective(result.x)
h_resid = equality_constraint(result.x)

print("\n--- Solution in Pyomo Model ---")
print(f"x1 = {value(m.x1):.6f}")
print(f"x2 = {value(m.x2):.6f}")
print(f"Constraint residual h(x): {h_resid:.6e}")
print(f"Raw objective (unpenalized): {f_raw:.6f}")
print(f"Penalty term (ρh²): {1e4 * h_resid**2:.6f}")


#P2

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, Constraint, sin, sqrt, value

# # ============================================================
# # 1. Define the Pyomo model (Eason’s Example)
# # ============================================================
# m = ConcreteModel()

# # Decision variables
# m.x = Var(range(5), domain=Reals, initialize=2.0)
# m.x[4].value = 1.0  # better initial guess for x4

# # Objective
# m.obj = Objective(
#     expr=(m.x[0] - 1.0)**2
#        + (m.x[0] - m.x[1])**2
#        + (m.x[2] - 1.0)**2
#        + (m.x[3] - 1.0)**4
#        + (m.x[4] - 1.0)**6
# )

# # Equality constraints (handled via penalty)
# m.c1 = Constraint(expr=m.x[3]*m.x[0]**2 + sin(m.x[3] - m.x[4]) - 2*sqrt(2.0) == 0)
# m.c2 = Constraint(expr=m.x[2]**4 * m.x[1]**2 + m.x[1] - 8 - sqrt(2.0) == 0)


# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Extract NumPy vector of variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Assign NumPy vector values to Pyomo variables."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def raw_objective(v):
#     """Return the unpenalized Pyomo objective value."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_residuals(v):
#     """Compute equality constraint residuals."""
#     set_vector(v)
#     h1 = value(m.c1.body)
#     h2 = value(m.c2.body)
#     return np.array([h1, h2])

# def penalized_objective(v, rho=1e4):
#     """Quadratic penalty formulation."""
#     f = raw_objective(v)
#     h = constraint_residuals(v)
#     return f + rho * np.sum(h**2)


# # ============================================================
# # 3. Initial guess and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.full(len(x0), -10.0)
# ub = np.full(len(x0), 10.0)
# bounds = list(zip(lb, ub))


# # ============================================================
# # 4. Solve with Nelder–Mead
# # ============================================================
# result = minimize(
#     lambda v: penalized_objective(v, rho=1e4),
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 20000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )


# # ============================================================
# # 5. Print results (standard benchmark format)
# # ============================================================
# print("\n--- Nelder–Mead (Penalty) Results ---")
# print(f"Success: {result.success}")
# print(f"Message: {result.message}")
# print(f"Objective (penalized): {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Solution x: {result.x}")

# # Push solution back to Pyomo model
# set_vector(result.x)

# # Evaluate constraint residuals and raw objective
# h = constraint_residuals(result.x)
# f_raw = raw_objective(result.x)

# print("\n--- Solution in Pyomo Model ---")
# for i in var_list:
#     print(f"x[{i}] = {value(m.x[i]):.6f}")

# print(f"Constraint residual h1(x): {h[0]:.6e}")
# print(f"Constraint residual h2(x): {h[1]:.6e}")
# print(f"Raw objective (unpenalized): {f_raw:.6f}")
# print(f"Penalty term (ρΣh²): {1e4 * np.sum(h**2):.6f}")




#P3

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import ConcreteModel, Var, Objective, Constraint, Reals, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Variables
# m.x1 = Var(initialize=0.0)
# m.x2 = Var(bounds=(-2.0, None), initialize=0.0)

# # Objective
# m.obj = Objective(expr=(m.x1 - 1)**2 + (m.x2 - 3)**2 + m.x1**2 + (m.x2**2)**2)

# # Equality constraint (handled via penalty)
# m.c1 = Constraint(expr=2*m.x1 + m.x2 + 10.0 - m.x1**2 - m.x2**2 == 0)


# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = [m.x1, m.x2]

# def get_vector():
#     """Extract NumPy vector of variable values."""
#     return np.array([value(v) for v in var_list])

# def set_vector(v):
#     """Assign NumPy vector values to Pyomo variables."""
#     for i, var in enumerate(var_list):
#         var.value = float(v[i])

# def raw_objective(v):
#     """Evaluate original Pyomo objective."""
#     set_vector(v)
#     return value(m.obj.expr)

# def equality_constraint(v):
#     """Compute equality constraint residual h(x)."""
#     set_vector(v)
#     return value(2*m.x1 + m.x2 + 10.0 - m.x1**2 - m.x2**2)

# def penalized_objective(v, rho=1e4):
#     """Quadratic penalty formulation for equality constraint."""
#     f = raw_objective(v)
#     h = equality_constraint(v)
#     return f + rho * (h**2)


# # ============================================================
# # 3. Bounds and initial guess
# # ============================================================
# x0 = get_vector()
# lb = np.array([-np.inf if v.lb is None else v.lb for v in var_list])
# ub = np.array([ np.inf if v.ub is None else v.ub for v in var_list])

# # Replace infinities with large finite values (Nelder–Mead doesn’t enforce bounds)
# lb = np.where(np.isinf(lb), -10.0, lb)
# ub = np.where(np.isinf(ub),  10.0, ub)
# bounds = list(zip(lb, ub))


# # ============================================================
# # 4. Solve with Nelder–Mead
# # ============================================================
# result = minimize(
#     lambda v: penalized_objective(v, rho=1e4),
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 2000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )


# # ============================================================
# # 5. Print results (benchmark-style)
# # ============================================================
# print("\n--- Nelder–Mead (Penalty) Results ---")
# print(f"Success: {result.success}")
# print(f"Message: {result.message}")
# print(f"Objective (penalized): {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Solution x: {result.x}")

# # Push solution back into Pyomo
# set_vector(result.x)

# # Evaluate raw objective and constraint residual
# h = equality_constraint(result.x)
# f_raw = raw_objective(result.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x1):.6f}")
# print(f"x2 = {value(m.x2):.6f}")
# print(f"Constraint residual h(x): {h:.6e}")
# print(f"Raw objective (no penalty): {f_raw:.6f}")
# print(f"Penalty term (ρh²): {1e4 * h**2:.6f}")




#P4

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value, cos

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# n = 3  # Dimension of the Rastrigin function

# m = ConcreteModel()
# m.x = Var(range(n), domain=Reals, initialize=0.0, bounds=(-5.12, 5.12))

# # Objective: Rastrigin function
# # f(x) = 10*n + Σ [x_i^2 - 10*cos(2πx_i)]
# m.obj = Objective(expr=10*n + sum(m.x[i]**2 - 10*cos(2*(22/7)*m.x[i]) for i in range(n)))


# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Extract NumPy vector of variable values from Pyomo model."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Assign NumPy vector values back into Pyomo model."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def objective(v):
#     """Objective function for Nelder–Mead."""
#     set_vector(v)
#     return value(m.obj.expr)


# # ============================================================
# # 3. Define bounds and starting point
# # ============================================================
# x0 = get_vector()
# lb = np.array([-5.12]*n)
# ub = np.array([ 5.12]*n)
# bounds = list(zip(lb, ub))  # Nelder–Mead ignores bounds but we define for clarity


# # ============================================================
# # 4. Solve with Nelder–Mead
# # ============================================================
# result = minimize(
#     objective,
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 2000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )


# # ============================================================
# # 5. Print results (benchmark-style)
# # ============================================================
# print("\n--- Nelder–Mead Results ---")
# print(f"Success: {result.success}")
# print(f"Message: {result.message}")
# print(f"Objective: {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Solution x: {result.x}")

# # Push solution back into Pyomo
# set_vector(result.x)

# print("\n--- Solution in Pyomo Model ---")
# for i in range(n):
#     print(f"x[{i}] = {value(m.x[i]):.6f}")
# print(f"Objective value in Pyomo: {value(m.obj.expr):.6f}")



#P5

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import ConcreteModel, Var, Objective, Constraint, Reals, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()
# m.x = Var(range(4), domain=Reals, initialize=0.0, bounds=(-2, 2))

# # Constraints (Rosen–Suzuki)
# m.c1 = Constraint(expr=-(8 - m.x[0]**2 - m.x[1]**2 - m.x[2]**2 - m.x[3]**2 - m.x[0] + m.x[1] - m.x[2] + m.x[3]) <= 0)
# m.c2 = Constraint(expr=-(10 - m.x[0]**2 - 2*m.x[1]**2 - m.x[2]**2 - 2*m.x[3]**2 + m.x[0] + m.x[3]) <= 0)
# m.c3 = Constraint(expr=-(5 - 2*m.x[0]**2 - m.x[1]**2 - m.x[2]**2 - 2*m.x[0] + m.x[1] + m.x[3]) <= 0)

# # Objective function
# m.obj = Objective(
#     expr=(
#         m.x[0]**2 + m.x[1]**2 + m.x[3]**2
#         - 5*m.x[0] - 5*m.x[1]
#         + 2*m.x[2]**2 - 21*m.x[2] + 7*m.x[3]
#     )
# )

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Extract NumPy vector of variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Assign NumPy vector values to Pyomo model."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def raw_objective(v):
#     """Compute original Pyomo objective."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_values(v):
#     """Return constraint residuals g(x) ≤ 0."""
#     set_vector(v)
#     return np.array([
#         value(m.c1.body),
#         value(m.c2.body),
#         value(m.c3.body)
#     ])

# def penalized_objective(v, rho=1e4):
#     """Quadratic penalty for constraint violations (g(x) > 0)."""
#     f = raw_objective(v)
#     g = constraint_values(v)
#     penalty = np.sum(np.maximum(g, 0)**2) * rho
#     return f + penalty


# # ============================================================
# # 3. Initial guess and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([-2.0]*4)
# ub = np.array([ 2.0]*4)
# bounds = list(zip(lb, ub))  # Nelder–Mead ignores bounds, included for clarity


# # ============================================================
# # 4. Solve with Nelder–Mead
# # ============================================================
# result = minimize(
#     lambda v: penalized_objective(v, rho=1e4),
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 3000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )


# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead (Penalty) Results ---")
# print(f"Success: {result.success}")
# print(f"Message: {result.message}")
# print(f"Objective (penalized): {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Solution x: {result.x}")

# # Push back to Pyomo model
# set_vector(result.x)

# # Compute residuals and raw objective
# f_raw = raw_objective(result.x)
# g_vals = constraint_values(result.x)

# print("\n--- Solution in Pyomo Model ---")
# for i in range(4):
#     print(f"x[{i}] = {value(m.x[i]):.6f}")
# print(f"Raw objective (no penalty): {f_raw:.6f}")
# print(f"Constraint values: {g_vals}")
# print(f"Total constraint violation penalty: {np.sum(np.maximum(g_vals, 0)**2) * 1e4:.6f}")



#P6

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import ConcreteModel, Var, Objective, Constraint, Reals, sin, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()
# m.x = Var(range(2), domain=Reals, initialize=0.0, bounds=(0, 1))

# # Constraints (g(x) ≤ 0)
# m.c1 = Constraint(expr=1.5 - m.x[0] - 2*m.x[1] - 0.5*sin(-4*(22/7)*m.x[1] + 2*(22/7)*m.x[0]**2) <= 0)
# m.c2 = Constraint(expr=m.x[0]**2 + m.x[1]**2 - 1.5 <= 0)

# # Objective
# m.obj = Objective(expr=sum(m.x[i] for i in range(2)))


# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Extract NumPy vector of variable values from Pyomo model."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Assign NumPy vector values to Pyomo model."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def raw_objective(v):
#     """Evaluate original Pyomo objective."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_values(v):
#     """Compute all constraint values g(x) ≤ 0."""
#     set_vector(v)
#     return np.array([
#         value(m.c1.body),
#         value(m.c2.body)
#     ])

# def penalized_objective(v, rho=1e4):
#     """Add quadratic penalties for any violated constraints."""
#     f = raw_objective(v)
#     g = constraint_values(v)
#     penalty = np.sum(np.maximum(g, 0)**2) * rho
#     return f + penalty


# # ============================================================
# # 3. Define bounds and initial guess
# # ============================================================
# x0 = get_vector()
# lb = np.array([0.0, 0.0])
# ub = np.array([1.0, 1.0])
# bounds = list(zip(lb, ub))  # For clarity; Nelder–Mead does not enforce bounds


# # ============================================================
# # 4. Solve with Nelder–Mead
# # ============================================================
# result = minimize(
#     lambda v: penalized_objective(v, rho=1e4),
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 2000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )


# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead (Penalty) Results ---")
# print(f"Success: {result.success}")
# print(f"Message: {result.message}")
# print(f"Objective (penalized): {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Solution x: {result.x}")

# # Push back into Pyomo model
# set_vector(result.x)

# # Evaluate raw objective and constraints
# f_raw = raw_objective(result.x)
# g_vals = constraint_values(result.x)

# print("\n--- Solution in Pyomo Model ---")
# for i in range(2):
#     print(f"x[{i}] = {value(m.x[i]):.6f}")
# print(f"Raw objective (no penalty): {f_raw:.6f}")
# print(f"Constraint values: {g_vals}")
# print(f"Total penalty: {np.sum(np.maximum(g_vals, 0)**2) * 1e4:.6f}")



#P7

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Variables
# m.x1 = Var(domain=Reals, initialize=0.0, bounds=(-2, 2))
# m.x2 = Var(domain=Reals, initialize=-1.0, bounds=(-2, 2))

# # Objective (Goldstein–Price function)
# m.obj = Objective(
#     expr=(1 + (m.x1 + m.x2 + 1)**2
#          * (19 - 14*m.x1 + 3*m.x1**2 - 14*m.x2 + 6*m.x1*m.x2 + 3*m.x2**2))
#         * (30 + (2*m.x1 - 3*m.x2)**2
#          * (18 - 32*m.x1 + 12*m.x1**2 + 48*m.x2 - 36*m.x1*m.x2 + 27*m.x2**2))
# )

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# def get_vector(model):
#     """Extract NumPy vector from Pyomo model."""
#     return np.array([value(model.x1), value(model.x2)])

# def set_vector(model, v):
#     """Set Pyomo variables from NumPy vector."""
#     model.x1.value = float(v[0])
#     model.x2.value = float(v[1])

# def objective(v):
#     """Objective callable for Nelder–Mead."""
#     set_vector(m, v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Define bounds and initial point
# # ============================================================
# x0 = get_vector(m)
# lb = np.array([-2.0, -2.0])
# ub = np.array([ 2.0,  2.0])
# bounds = list(zip(lb, ub))  # Nelder–Mead ignores bounds, but kept for clarity

# # ============================================================
# # 4. Solve with Nelder–Mead
# # ============================================================
# result = minimize(
#     objective,
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 3000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead Results ---")
# print(f"Success: {result.success}")
# print(f"Message: {result.message}")
# print(f"Objective: {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Solution x: {result.x}")

# # Push solution back into Pyomo
# set_vector(m, result.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x1):.6f}")
# print(f"x2 = {value(m.x2):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")



#P8

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import ConcreteModel, Var, Objective, Constraint, Reals, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Decision variables
# m.x1 = Var(initialize=80, bounds=(78, 102))
# m.x2 = Var(initialize=35, bounds=(33, 45))
# m.x3 = Var(initialize=30, bounds=(27, 45))
# m.x4 = Var(initialize=30, bounds=(27, 45))
# m.x5 = Var(initialize=30, bounds=(27, 45))

# # Constraints (g(x) ≤ 0)
# m.c1 = Constraint(expr=0.00002584*m.x3*m.x5 - 0.00006663*m.x2*m.x5 - 0.0000734*m.x1*m.x4 - 1 <= 0)
# m.c2 = Constraint(expr=0.000853007*m.x2*m.x5 + 0.00009395*m.x1*m.x4 - 0.00033085*m.x3*m.x5 - 1 <= 0)
# m.c3 = Constraint(expr=1330.3294*((m.x2*m.x5)**(-1)) - 0.42*m.x1*((m.x5)**(-1)) - 0.30586*((m.x2*m.x5)**(-1))*m.x3**2 - 1 <= 0)
# m.c4 = Constraint(expr=0.00024186*m.x2*m.x5 + 0.00010159*m.x1*m.x2 + 0.00007379*m.x3**2 - 1 <= 0)
# m.c5 = Constraint(expr=2275.1327*((m.x3*m.x5)**(-1)) - 0.2668*m.x1*((m.x5)**(-1)) - 0.40584*((m.x5)**(-1))*m.x4 - 1 <= 0)
# m.c6 = Constraint(expr=0.00029955*m.x3*m.x5 + 0.00007992*m.x1*m.x2 + 0.00012157*m.x3*m.x4 - 1 <= 0)

# # Objective
# m.obj = Objective(expr=5.3578*m.x3**2 + 0.8357*m.x1*m.x5 + 37.2392*m.x1)

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = [m.x1, m.x2, m.x3, m.x4, m.x5]
# con_list = [m.c1, m.c2, m.c3, m.c4, m.c5, m.c6]

# def get_vector():
#     """Return NumPy vector of variable values."""
#     return np.array([value(v) for v in var_list])

# def set_vector(v):
#     """Assign NumPy vector values back into Pyomo model."""
#     for i, var in enumerate(var_list):
#         var.value = float(v[i])

# def raw_objective(v):
#     """Evaluate the Pyomo objective function."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_values(v):
#     """Return all g_i(x) values."""
#     set_vector(v)
#     return np.array([value(c.body) for c in con_list])

# def penalized_objective(v, rho=1e8):
#     """Objective + quadratic penalties for constraint violations."""
#     f = raw_objective(v)
#     g = constraint_values(v)
#     penalty = np.sum(np.maximum(g, 0)**2) * rho
#     return f + penalty

# # ============================================================
# # 3. Initial guess and bounds (for reporting)
# # ============================================================
# x0 = get_vector()
# lb = np.array([v.lb for v in var_list], dtype=float)
# ub = np.array([v.ub for v in var_list], dtype=float)
# bounds = list(zip(lb, ub))  # not used by Nelder–Mead

# # ============================================================
# # 4. Solve with Nelder–Mead
# # ============================================================
# result = minimize(
#     lambda v: penalized_objective(v, rho=1e8),
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 3000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead (Penalty) Results ---")
# print(f"Success: {result.success}")
# print(f"Message: {result.message}")
# print(f"Objective (penalized): {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Solution x: {result.x}")

# # Push solution back into Pyomo model
# set_vector(result.x)

# # Evaluate raw objective and constraints
# f_raw = raw_objective(result.x)
# g_vals = constraint_values(result.x)

# print("\n--- Solution in Pyomo Model ---")
# for i, var in enumerate(var_list):
#     print(f"x[{i+1}] = {value(var):.6f}")
# print(f"Objective (no penalty): {f_raw:.6f}")
# print(f"Constraint values: {g_vals}")
# print(f"Total penalty: {np.sum(np.maximum(g_vals, 0)**2) * 1e8:.6f}")



#P10

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Decision variables
# m.x1 = Var(domain=Reals, initialize=3.0, bounds=(-4, 5))
# m.x2 = Var(domain=Reals, initialize=-0.256837, bounds=(-4, 5))
# m.x3 = Var(domain=Reals, initialize=0.517729, bounds=(-4, 5))
# m.x4 = Var(domain=Reals, initialize=2.244261, bounds=(-4, 5))

# # Objective (Powell singular function)
# m.obj = Objective(
#     expr=(m.x1 + 10*m.x2)**2
#         + 5*(m.x3 - m.x4)**2
#         + (m.x2 - 2*m.x3)**4
#         + 10*(m.x1 - m.x4)**4
# )

# # ============================================================
# # 2. Bridge Pyomo ↔ NumPy
# # ============================================================
# var_list = [m.x1, m.x2, m.x3, m.x4]

# def get_vector():
#     """Return NumPy vector of variable values."""
#     return np.array([value(v) for v in var_list])

# def set_vector(v):
#     """Assign NumPy vector values to Pyomo variables."""
#     for i, var in enumerate(var_list):
#         var.value = float(v[i])

# def objective(v):
#     """Objective function evaluation for Nelder–Mead."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Initial point and bounds (for reference only)
# # ============================================================
# x0 = get_vector()
# lb = np.array([v.lb for v in var_list], dtype=float)
# ub = np.array([v.ub for v in var_list], dtype=float)
# bounds = list(zip(lb, ub))  # Nelder–Mead ignores bounds

# # ============================================================
# # 4. Solve using Nelder–Mead
# # ============================================================
# result = minimize(
#     objective,
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 3000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead Results ---")
# print(f"Success: {result.success}")
# print(f"Message: {result.message}")
# print(f"Objective: {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Solution x: {result.x}")

# # Push back into Pyomo model
# set_vector(result.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x1):.6f}")
# print(f"x2 = {value(m.x2):.6f}")
# print(f"x3 = {value(m.x3):.6f}")
# print(f"x4 = {value(m.x4):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")



#P11

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, sin, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Decision variable
# m.x = Var(domain=Reals, initialize=1.0, bounds=(0.5, 2.5))

# # Objective: f(x) = sin(10πx)/(2x) + (x − 1)^4
# m.obj = Objective(expr=sin(10*(22/7)*m.x)/(2*m.x) + (m.x - 1)**4)

# # ============================================================
# # 2. Bridge Pyomo ↔ NumPy
# # ============================================================
# def get_vector():
#     """Return NumPy vector of variable values."""
#     return np.array([value(m.x)])

# def set_vector(v):
#     """Assign value to Pyomo variable."""
#     m.x.value = float(v[0])

# def objective(v):
#     """Objective function evaluation for Nelder–Mead."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Initial guess and bounds (for reference)
# # ============================================================
# x0 = get_vector()
# lb = np.array([m.x.lb])
# ub = np.array([m.x.ub])
# bounds = list(zip(lb, ub))  # Nelder–Mead ignores bounds

# # ============================================================
# # 4. Solve using Nelder–Mead
# # ============================================================
# result = minimize(
#     objective,
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 2000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead Results ---")
# print(f"Success: {result.success}")
# print(f"Message: {result.message}")
# print(f"Objective: {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Solution x: {result.x}")

# # Push solution back to Pyomo model
# set_vector(result.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x = {value(m.x):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")



#P12

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value, cos, exp

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Variables
# m.x = Var(range(2), domain=Reals, initialize=0.0, bounds=(-100, 100))

# # Objective: f(x) = -cos(x0)*cos(x1)*exp(-((x0 - π)^2 + (x1 - π)^2))
# m.obj = Objective(
#     expr = -cos(m.x[0]) * cos(m.x[1]) *
#            exp(-((m.x[0] - (22/7))**2 + (m.x[1] - (22/7))**2))
# )

# # ============================================================
# # 2. Bridge Pyomo ↔ NumPy
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Return NumPy vector of variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Assign NumPy vector values to Pyomo variables."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def objective(v):
#     """Objective function for Nelder–Mead."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Initial guess and bounds (for reference)
# # ============================================================
# x0 = get_vector()
# lb = np.array([-100.0, -100.0])
# ub = np.array([100.0, 100.0])
# bounds = list(zip(lb, ub))  # Nelder–Mead ignores bounds but we record them

# # ============================================================
# # 4. Solve using Nelder–Mead
# # ============================================================
# result = minimize(
#     objective,
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 3000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead Results ---")
# print(f"Success: {result.success}")
# print(f"Message: {result.message}")
# print(f"Objective: {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Solution x: {result.x}")

# # Push solution back to Pyomo model
# set_vector(result.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x0 = {value(m.x[0]):.6f}")
# print(f"x1 = {value(m.x[1]):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")




#P13

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()
# m.x1 = Var(domain=Reals, initialize=0.1, bounds=(-3, 2))
# m.x2 = Var(domain=Reals, initialize=0.1, bounds=(-2, 2))

# # Objective: Six-Hump Camelback function
# m.obj = Objective(
#     expr=4*m.x1**2 - 2.1*m.x1**4 + (m.x1**6)/3 + m.x1*m.x2 - 4*m.x2**2 + 4*m.x2**4
# )

# # ============================================================
# # 2. Bridge Pyomo ↔ NumPy
# # ============================================================
# var_list = [m.x1, m.x2]

# def get_vector():
#     """Return NumPy vector of variable values."""
#     return np.array([value(v) for v in var_list])

# def set_vector(v):
#     """Assign NumPy vector values to Pyomo variables."""
#     for i, var in enumerate(var_list):
#         var.value = float(v[i])

# def objective(v):
#     """Objective function for Nelder–Mead."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Initial point and bounds (for reference)
# # ============================================================
# x0 = get_vector()
# lb = np.array([v.lb for v in var_list])
# ub = np.array([v.ub for v in var_list])
# bounds = list(zip(lb, ub))  # Nelder–Mead ignores bounds but we store them

# # ============================================================
# # 4. Solve using Nelder–Mead
# # ============================================================
# result = minimize(
#     objective,
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 3000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead Results ---")
# print(f"Success: {result.success}")
# print(f"Message: {result.message}")
# print(f"Objective: {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Solution x: {result.x}")

# # Push solution back to Pyomo model
# set_vector(result.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x1):.6f}")
# print(f"x2 = {value(m.x2):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")



#P14

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()
# m.x = Var(range(2), domain=Reals, initialize=0.0, bounds=(-5, 5))

# # Objective: Three-Hump Camel Function
# m.obj = Objective(
#     expr = 2*(m.x[0]**2)
#          - 1.05*(m.x[0]**4)
#          + (m.x[0]**6)/6
#          + (m.x[0]*m.x[1])
#          + (m.x[1]**2)
# )

# # ============================================================
# # 2. Bridge Pyomo ↔ NumPy
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Return NumPy vector of variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Assign NumPy vector values to Pyomo variables."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def objective(v):
#     """Objective function for Nelder–Mead."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Initial point and bounds (for reference)
# # ============================================================
# x0 = get_vector()
# lb = np.array([-5.0, -5.0])
# ub = np.array([ 5.0,  5.0])
# bounds = list(zip(lb, ub))  # Nelder–Mead ignores bounds, but we include for consistency

# # ============================================================
# # 4. Solve using Nelder–Mead
# # ============================================================
# result = minimize(
#     objective,
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 2000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead Results ---")
# print(f"Success: {result.success}")
# print(f"Message: {result.message}")
# print(f"Objective: {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Solution x: {result.x}")

# # Push solution back to Pyomo model
# set_vector(result.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")



#P15

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, sin, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds={0: (-1.5, 4.0), 1: (-3.0, 4.0)}
# )

# # Objective: f(x1, x2) = sin(x1 + x2) + (x1 - x2)^2 - 1.5x1 + 2.5x2 + 1
# m.obj = Objective(
#     expr = sin(m.x[0] + m.x[1])
#          + (m.x[0] - m.x[1])**2
#          - 1.5*m.x[0]
#          + 2.5*m.x[1]
#          + 1
# )

# # ============================================================
# # 2. Bridge Pyomo ↔ NumPy
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Return NumPy vector of variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Assign NumPy vector back to Pyomo variables."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def objective(v):
#     """Objective callable for Nelder–Mead."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Define initial guess and bounds (for reference)
# # ============================================================
# x0 = get_vector()
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])
# bounds = list(zip(lb, ub))  # Nelder–Mead ignores bounds, but we record them

# # ============================================================
# # 4. Solve with Nelder–Mead
# # ============================================================
# result = minimize(
#     objective,
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 3000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead Results ---")
# print(f"Success: {result.success}")
# print(f"Message: {result.message}")
# print(f"Objective: {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Solution x: {result.x}")

# # Push solution back to Pyomo model
# set_vector(result.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")



#P16

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-10, 10)
# )

# # Objective: Matyas function
# m.obj = Objective(
#     expr = 0.26*(m.x[0]**2 + m.x[1]**2) - 0.48*m.x[0]*m.x[1]
# )

# # ============================================================
# # 2. Bridge Pyomo ↔ NumPy
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Extract NumPy vector of Pyomo variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Push NumPy vector values into Pyomo model."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def objective(v):
#     """Objective callable for Nelder–Mead."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Define bounds and starting point
# # ============================================================
# x0 = get_vector()
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])
# bounds = list(zip(lb, ub))  # for record (Nelder–Mead ignores bounds)

# # ============================================================
# # 4. Solve using Nelder–Mead
# # ============================================================
# result = minimize(
#     objective,
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 2000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead Results ---")
# print(f"Success: {result.success}")
# print(f"Message: {result.message}")
# print(f"Objective: {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Solution x: {result.x}")

# # Push solution back to Pyomo model
# set_vector(result.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")



#P17
# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value, cos

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-100, 100)
# )

# # Objective:
# # f(x1, x2) = x1² + 2x2² - 0.3*cos(3πx1)*cos(4πx2) + 0.3
# m.obj = Objective(
#     expr = (m.x[0]**2)
#          + 2*(m.x[1]**2)
#          - 0.3*cos(3*(22/7)*m.x[0])*cos(4*(22/7)*m.x[1])
#          + 0.3
# )

# # ============================================================
# # 2. Bridge Pyomo ↔ NumPy
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Extract NumPy vector from Pyomo variables."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Update Pyomo variables with NumPy vector values."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def objective(v):
#     """Objective callable for Nelder–Mead."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Define bounds and initial point
# # ============================================================
# x0 = get_vector()
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])
# bounds = list(zip(lb, ub))  # for reference (ignored by Nelder–Mead)

# # ============================================================
# # 4. Solve using Nelder–Mead
# # ============================================================
# result = minimize(
#     objective,
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 2000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead Results ---")
# print(f"Success: {result.success}")
# print(f"Message: {result.message}")
# print(f"Objective: {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Solution x: {result.x}")

# # Push the solution back to the Pyomo model
# set_vector(result.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")



#P18

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value, cos

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-100, 100)
# )

# # Objective:
# # f(x1, x2) = x1² + 2x2² - 0.3*cos(3πx1 + 4πx2) + 0.3
# m.obj = Objective(
#     expr = m.x[0]**2
#          + 2*m.x[1]**2
#          - 0.3*cos(3*(22/7)*m.x[0] + 4*(22/7)*m.x[1])
#          + 0.3
# )

# # ============================================================
# # 2. Bridge Pyomo ↔ NumPy
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Extract NumPy vector of variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Push NumPy vector values into Pyomo model."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def objective(v):
#     """Objective callable for Nelder–Mead."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Define bounds and starting point
# # ============================================================
# x0 = get_vector()
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])
# bounds = list(zip(lb, ub))  # for record (Nelder–Mead ignores bounds)

# # ============================================================
# # 4. Solve using Nelder–Mead
# # ============================================================
# result = minimize(
#     objective,
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 2000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead Results ---")
# print(f"Success: {result.success}")
# print(f"Message: {result.message}")
# print(f"Objective: {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Solution x: {result.x}")

# # Push solution back to Pyomo model
# set_vector(result.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")




#P19
# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Reals, value, minimize as pyo_minimize, cos
# )

# # ============================================================
# # 1. Define your black-box function
# # ============================================================
# def blackbox(v):
#     """
#     Black-box function f(x1, x2).
#     (This could be a simulation, CFD model, or external code.)
#     """
#     x1, x2 = v
#     return x1**2 + 2*x2**2 - 0.3*np.cos(3*np.pi*x1 + 4*np.pi*x2) + 0.3


# # ============================================================
# # 2. Define the Pyomo model (symbolic representation)
# # ============================================================
# m = ConcreteModel()

# # Two decision variables
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-100, 100)
# )

# # Objective (for validation only — not used by solver)
# m.obj = Objective(
#     expr = m.x[0]**2 + 2*m.x[1]**2
#          - 0.3*cos((3*(22/7)*m.x[0]) + (4*(22/7)*m.x[1])) + 0.3,
#     sense = pyo_minimize
# )


# # ============================================================
# # 3. Bridge Pyomo ↔ NumPy
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Return NumPy vector of current variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Update model variables from NumPy vector."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def objective(v):
#     """Objective callable for Nelder–Mead."""
#     return blackbox(v)


# # ============================================================
# # 4. Initial vector and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])
# bounds = list(zip(lb, ub))  # For reference; Nelder–Mead ignores bounds

# # ============================================================
# # 5. Solve using Nelder–Mead
# # ============================================================
# result = minimize(
#     objective,
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 2000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )


# # ============================================================
# # 6. Print results
# # ============================================================
# print("\n--- Nelder–Mead Results ---")
# print(f"Success flag       : {result.success}")
# print(f"Message            : {result.message}")
# print(f"Objective value    : {result.fun:.6f}")
# print(f"Function evals     : {result.nfev}")
# print(f"Best solution (x*) : {result.x}")

# # Push the solution back to the Pyomo model
# set_vector(result.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Objective (Pyomo)  : {value(m.obj.expr):.6f}")







#P20
# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize as pyo_minimize
# )

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-2, 2)
# )

# # Objective: Rosenbrock function
# m.obj = Objective(
#     expr=(1 - m.x[0])**2 + 100*(m.x[1] - m.x[0]**2)**2,
#     sense=pyo_minimize
# )

# # Constraints:
# # g1(x) = x1 + x2 - 1 ≤ 0
# # g2(x) = x1² + x2² - 1 ≤ 0
# m.con1 = Constraint(expr=m.x[0] + m.x[1] - 1 <= 0)
# m.con2 = Constraint(expr=m.x[0]**2 + m.x[1]**2 - 1 <= 0)


# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Return NumPy vector of current variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Update model variables from NumPy vector."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def raw_objective(v):
#     """Evaluate the original Rosenbrock objective."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_violation(v):
#     """Compute inequality constraint violations (positive parts)."""
#     set_vector(v)
#     g1 = value(m.x[0] + m.x[1] - 1)
#     g2 = value(m.x[0]**2 + m.x[1]**2 - 1)
#     return np.maximum([g1, g2], 0.0)

# def penalized_objective(v, rho=1e4):
#     """Quadratic penalty formulation for constraint violations."""
#     f = raw_objective(v)
#     g_viols = constraint_violation(v)
#     return f + rho * np.sum(g_viols**2)


# # ============================================================
# # 3. Initial point and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])
# bounds = list(zip(lb, ub))  # for reference; ignored by Nelder–Mead


# # ============================================================
# # 4. Solve using Nelder–Mead
# # ============================================================
# result = minimize(
#     lambda v: penalized_objective(v, rho=1e4),
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 3000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )


# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead (Penalty) Results ---")
# print(f"Success flag       : {result.success}")
# print(f"Message            : {result.message}")
# print(f"Penalized Objective: {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Best solution (x*) : {result.x}")

# # Push solution back into Pyomo
# set_vector(result.x)

# # Evaluate final constraint info
# raw_f = raw_objective(result.x)
# g_viol = constraint_violation(result.x)
# total_violation = np.sum(g_viol)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Raw Objective f(x): {raw_f:.6f}")
# print(f"Total Constraint Violation: {total_violation:.2e}")


#P21

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize as pyo_minimize
# )

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Two decision variables
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-4.5, 4.5)
# )

# # Objective: Beale function
# # f(x1,x2) = (1.5 - x1 + x1*x2)² + (2.25 - x1 + x1*x2²)² + (2.625 - x1 + x1*x2³)²
# m.obj = Objective(
#     expr = (1.5 - m.x[0] + m.x[0]*m.x[1])**2
#          + (2.25 - m.x[0] + m.x[0]*m.x[1]**2)**2
#          + (2.625 - m.x[0] + m.x[0]*m.x[1]**3)**2,
#     sense = pyo_minimize
# )

# # Constraints:
# # g1(x) = x1 + x2 - 3 ≤ 0
# # g2(x) = x1² + x2² - 5 ≤ 0
# m.con1 = Constraint(expr = m.x[0] + m.x[1] - 3 <= 0)
# m.con2 = Constraint(expr = m.x[0]**2 + m.x[1]**2 - 5 <= 0)


# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Return NumPy vector of current variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Update model variables from NumPy vector."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def raw_objective(v):
#     """Beale objective function."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_violation(v):
#     """Return positive constraint violations (g_i(x) > 0)."""
#     set_vector(v)
#     g1 = value(m.x[0] + m.x[1] - 3)
#     g2 = value(m.x[0]**2 + m.x[1]**2 - 5)
#     return np.maximum([g1, g2], 0.0)

# def penalized_objective(v, rho=1e4):
#     """Quadratic penalty for constraint violations."""
#     f = raw_objective(v)
#     g_viol = constraint_violation(v)
#     return f + rho * np.sum(g_viol**2)


# # ============================================================
# # 3. Initial point and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])
# bounds = list(zip(lb, ub))  # recorded for reference


# # ============================================================
# # 4. Solve using Nelder–Mead
# # ============================================================
# result = minimize(
#     lambda v: penalized_objective(v, rho=1e4),
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 3000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )


# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead (Penalty) Results ---")
# print(f"Success flag        : {result.success}")
# print(f"Message             : {result.message}")
# print(f"Penalized Objective : {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Best solution (x*)  : {result.x}")

# # Push solution back into Pyomo
# set_vector(result.x)

# # Evaluate details
# raw_f = raw_objective(result.x)
# viol = constraint_violation(result.x)
# total_violation = np.sum(viol)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Raw Objective f(x)  : {raw_f:.6f}")
# print(f"Constraint Violation: {total_violation:.2e}")



#P22

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize as pyo_minimize
# )

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-10, 10)
# )

# # Objective: Booth function
# # f(x1, x2) = (x1 + 2x2 - 7)² + (2x1 + x2 - 5)²
# m.obj = Objective(
#     expr = (m.x[0] + 2*m.x[1] - 7)**2 + (2*m.x[0] + m.x[1] - 5)**2,
#     sense = pyo_minimize
# )

# # Constraints:
# # g1(x) = x1 + x2 - 10 ≤ 0
# # g2(x) = x1² + x2² - 50 ≤ 0
# m.con1 = Constraint(expr = m.x[0] + m.x[1] - 10 <= 0)
# m.con2 = Constraint(expr = m.x[0]**2 + m.x[1]**2 - 50 <= 0)


# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Return NumPy vector of current variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Update Pyomo variables from NumPy vector."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def raw_objective(v):
#     """Evaluate Booth function objective."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_violation(v):
#     """Return positive constraint violations (g_i(x) > 0)."""
#     set_vector(v)
#     g1 = value(m.x[0] + m.x[1] - 10)
#     g2 = value(m.x[0]**2 + m.x[1]**2 - 50)
#     return np.maximum([g1, g2], 0.0)

# def penalized_objective(v, rho=1e4):
#     """Quadratic penalty formulation."""
#     f = raw_objective(v)
#     g_viol = constraint_violation(v)
#     return f + rho * np.sum(g_viol**2)


# # ============================================================
# # 3. Initial point and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])
# bounds = list(zip(lb, ub))  # Nelder–Mead ignores bounds but kept for reference


# # ============================================================
# # 4. Solve using Nelder–Mead
# # ============================================================
# result = minimize(
#     lambda v: penalized_objective(v, rho=1e4),
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 3000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )


# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead (Penalty) Results ---")
# print(f"Success flag        : {result.success}")
# print(f"Message             : {result.message}")
# print(f"Penalized Objective : {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Best solution (x*)  : {result.x}")

# # Push results back to Pyomo
# set_vector(result.x)

# # Evaluate final details
# raw_f = raw_objective(result.x)
# viol = constraint_violation(result.x)
# total_violation = np.sum(viol)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Raw Objective f(x)  : {raw_f:.6f}")
# print(f"Constraint Violation: {total_violation:.2e}")



#P23
# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize as pyo_minimize
# )

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Two decision variables
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-5, 5)
# )

# # Objective:
# # f(x1, x2) = 0.5 * [ (x1⁴ − 16x1² + 5x1) + (x2⁴ − 16x2² + 5x2) ]
# m.obj = Objective(
#     expr = (
#         (m.x[0]**4 - 16*m.x[0]**2 + 5*m.x[0]) +
#         (m.x[1]**4 - 16*m.x[1]**2 + 5*m.x[1])
#     ) / 2,
#     sense = pyo_minimize
# )

# # Constraints:
# # g1(x) = x1 + x2 - 10 ≤ 0
# # g2(x) = x1² + x2² - 50 ≤ 0
# m.con1 = Constraint(expr = m.x[0] + m.x[1] - 10 <= 0)
# m.con2 = Constraint(expr = m.x[0]**2 + m.x[1]**2 - 50 <= 0)


# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Return NumPy vector of current variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Update Pyomo variables from a NumPy vector."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def raw_objective(v):
#     """Evaluate Pyomo objective."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_violation(v):
#     """Return positive constraint violations (g_i(x) > 0)."""
#     set_vector(v)
#     g1 = value(m.x[0] + m.x[1] - 10)
#     g2 = value(m.x[0]**2 + m.x[1]**2 - 50)
#     return np.maximum([g1, g2], 0.0)

# def penalized_objective(v, rho=1e4):
#     """Quadratic penalty function for constrained optimization."""
#     f = raw_objective(v)
#     g_viol = constraint_violation(v)
#     return f + rho * np.sum(g_viol**2)


# # ============================================================
# # 3. Initial point and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])
# bounds = list(zip(lb, ub))  # Nelder–Mead ignores bounds but kept for reference


# # ============================================================
# # 4. Solve using Nelder–Mead
# # ============================================================
# result = minimize(
#     lambda v: penalized_objective(v, rho=1e4),
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 3000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )


# # ============================================================
# # 5. Display results
# # ============================================================
# print("\n--- Nelder–Mead (Penalty) Results ---")
# print(f"Success flag        : {result.success}")
# print(f"Message             : {result.message}")
# print(f"Penalized Objective : {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Best solution (x*)  : {result.x}")

# # Push back to Pyomo
# set_vector(result.x)

# # Evaluate objective and constraint residuals
# raw_f = raw_objective(result.x)
# viol = constraint_violation(result.x)
# total_violation = np.sum(viol)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Raw Objective f(x)  : {raw_f:.6f}")
# print(f"Constraint Violation: {total_violation:.2e}")



#P24

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize as pyo_minimize
# )

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Two decision variables (unbounded)
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0}
# )

# # Original problem: maximize (x1 - 1)^2 + x2^2
# # Convert to minimization for Pyomo/Nelder–Mead
# m.obj = Objective(
#     expr = -((m.x[0] - 1)**2 + m.x[1]**2),
#     sense = pyo_minimize
# )

# # Constraints:
# # g1(x) = x1² + 6x2 - 36 ≤ 0
# # g2(x) = -4x1 + x2² - 2x2 ≤ 0
# m.con1 = Constraint(expr = m.x[0]**2 + 6*m.x[1] - 36 <= 0)
# m.con2 = Constraint(expr = -4*m.x[0] + m.x[1]**2 - 2*m.x[1] <= 0)


# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Return NumPy vector of variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Assign NumPy vector values back to model."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def raw_objective(v):
#     """Evaluate Pyomo objective (minimization form)."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_violation(v):
#     """Compute positive constraint violations (g_i(x) > 0)."""
#     set_vector(v)
#     g1 = value(m.x[0]**2 + 6*m.x[1] - 36)
#     g2 = value(-4*m.x[0] + m.x[1]**2 - 2*m.x[1])
#     return np.maximum([g1, g2], 0.0)

# def penalized_objective(v, rho=1e4):
#     """Quadratic penalty formulation for constraint violations."""
#     f = raw_objective(v)
#     g_viol = constraint_violation(v)
#     return f + rho * np.sum(g_viol**2)


# # ============================================================
# # 3. Initial point and bounds
# # ============================================================
# x0 = get_vector()
# # Nelder–Mead ignores bounds, but we keep them for reference
# lb = np.array([-100.0, -100.0])
# ub = np.array([100.0, 100.0])
# bounds = list(zip(lb, ub))


# # ============================================================
# # 4. Solve using Nelder–Mead
# # ============================================================
# result = minimize(
#     lambda v: penalized_objective(v, rho=1e4),
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 3000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )


# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead (Penalty) Results ---")
# print(f"Success flag        : {result.success}")
# print(f"Message             : {result.message}")
# print(f"Penalized Objective : {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Best solution (x*)  : {result.x}")

# # Push back to Pyomo model
# set_vector(result.x)

# # Evaluate detailed info
# raw_f = raw_objective(result.x)
# viol = constraint_violation(result.x)
# total_violation = np.sum(viol)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Raw Objective f(x)  : {raw_f:.6f}  (this is -maximization value)")
# print(f"Constraint Violation: {total_violation:.2e}")
# print(f"True maximization value = {-raw_f:.6f}")


#P25

# import numpy as np
# from scipy.optimize import minimize
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize as pyo_minimize
# )

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Two decision variables with given bounds
# m.x = Var(
#     range(2),
#     bounds={0: (0, None), 1: (0, 1.8)},
#     initialize={0: 0.0, 1: 0.0}
# )

# # Original problem: maximize  2x1 - x1² + x2
# # Convert to minimization of the negative objective
# m.obj = Objective(
#     expr = -(2*m.x[0] - m.x[0]**2 + m.x[1]),
#     sense = pyo_minimize
# )

# # Constraint: x1² + x2² ≤ 4
# m.con1 = Constraint(expr = m.x[0]**2 + m.x[1]**2 - 4 <= 0)


# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Return NumPy vector of variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Assign NumPy vector back to model variables."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def raw_objective(v):
#     """Evaluate Pyomo objective."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_violation(v):
#     """Compute positive constraint violation."""
#     set_vector(v)
#     g1 = value(m.x[0]**2 + m.x[1]**2 - 4)
#     return max(g1, 0.0)

# def penalized_objective(v, rho=1e4):
#     """Quadratic penalty formulation."""
#     f = raw_objective(v)
#     g_viol = constraint_violation(v)
#     return f + rho * g_viol**2


# # ============================================================
# # 3. Initial point and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([
#     m.x[i].lb if m.x[i].lb is not None else -100.0
#     for i in var_list
# ])
# ub = np.array([
#     m.x[i].ub if m.x[i].ub is not None else 100.0
#     for i in var_list
# ])
# bounds = list(zip(lb, ub))  # Nelder–Mead ignores these but kept for completeness


# # ============================================================
# # 4. Solve using Nelder–Mead
# # ============================================================
# result = minimize(
#     lambda v: penalized_objective(v, rho=1e4),
#     x0,
#     method='Nelder-Mead',
#     bounds=bounds,
#     options={'maxiter': 3000, 'disp': True, 'xatol': 1e-8, 'fatol': 1e-8}
# )


# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- Nelder–Mead (Penalty) Results ---")
# print(f"Success flag        : {result.success}")
# print(f"Message             : {result.message}")
# print(f"Penalized Objective : {result.fun:.6f}")
# print(f"Function evaluations: {result.nfev}")
# print(f"Best solution (x*)  : {result.x}")

# # Push back to Pyomo
# set_vector(result.x)

# # Evaluate final info
# raw_f = raw_objective(result.x)
# viol = constraint_violation(result.x)
# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Raw Objective f(x)  : {raw_f:.6f}  (negative of maximization)")
# print(f"Constraint Violation: {viol:.2e}")
# print(f"True maximization value = {-raw_f:.6f}")



#P25












