# -*- coding: utf-8 -*-
"""
Created on Mon Nov  3 09:49:18 2025

@author: gh00616
"""

#P1

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import ConcreteModel, Var, Reals, Objective, Constraint, value

# # ============================================================
# # 1. Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Decision variables
# m.x1 = Var(initialize=0.0)
# m.x2 = Var(bounds=(-2.0, None), initialize=0.0)

# # Objective: (x1 - 1)^2 + (x2 - 3)^2 + x1^2 + (x2^2)^2
# m.obj = Objective(expr=(m.x1 - 1)**2 + (m.x2 - 3)**2 + m.x1**2 + (m.x2**2)**2)

# # Equality constraint: 2x1 + x2 + 10 - x1^2 - x2^2 = 0
# m.c1 = Constraint(expr=2*m.x1 + m.x2 + 10.0 - m.x1**2 - m.x2**2 == 0)

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = [m.x1, m.x2]

# def get_vector():
#     return np.array([value(v) for v in var_list])

# def set_vector(v):
#     for val, var in zip(v, var_list):
#         var.value = float(val)

# def raw_objective(v):
#     set_vector(v)
#     return value(m.obj.expr)

# def equality_constraint(v):
#     set_vector(v)
#     return value(m.c1.body)

# def penalized_objective(v, rho=1e6):
#     """Quadratic penalty on equality h(x)=0."""
#     f = raw_objective(v)
#     h = equality_constraint(v)
#     return f + rho * h**2

# # ============================================================
# # 3. Initial guess (no bounds for NEWUOA)
# # ============================================================
# x0 = get_vector()

# # ============================================================
# # 4. Solve with NEWUOA via PDFO
# # ============================================================
# res = pdfo(
#     fun=lambda v: penalized_objective(v, rho=1e6),
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 20000,
#         'rhobeg': 1.0,
#         'rhoend': 1e-6,   # final trust-region radius
#     }
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- NEWUOA (Penalty) Results ---")
# print(f"Success: {res.success}")
# print(f"Message: {res.message}")
# print(f"Objective (penalized): {res.fun:.6f}")
# print(f"Function evaluations : {res.nfev}")
# print(f"Best solution (x*)   : {res.x}")

# # Push back to Pyomo
# set_vector(res.x)

# f_raw = raw_objective(res.x)
# h_resid = equality_constraint(res.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x1):.6f}")
# print(f"x2 = {value(m.x2):.6f}")
# print(f"Constraint residual h(x): {h_resid:.6e}")
# print(f"Raw objective (unpenalized): {f_raw:.6f}")
# print(f"Penalty term (ρh²): {1e6 * h_resid**2:.6f}")



#P2

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import ConcreteModel, Var, Objective, Constraint, Reals, sin, sqrt, value

# # ============================================================
# # 1. Define the Pyomo model (Eason’s Example)
# # ============================================================
# m = ConcreteModel()

# # Decision variables
# m.x = Var(range(5), domain=Reals, initialize=2.0)
# m.x[4].value = 1.0  # better initial guess for x4

# # Objective
# m.obj = Objective(
#     expr=(m.x[0] - 1.0)**2
#        + (m.x[0] - m.x[1])**2
#        + (m.x[2] - 1.0)**2
#        + (m.x[3] - 1.0)**4
#        + (m.x[4] - 1.0)**6
# )

# # Equality constraints (handled via penalty)
# m.c1 = Constraint(expr=m.x[3]*m.x[0]**2 + sin(m.x[3] - m.x[4]) - 2*sqrt(2.0) == 0)
# m.c2 = Constraint(expr=m.x[2]**4 * m.x[1]**2 + m.x[1] - 8 - sqrt(2.0) == 0)

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     for val, idx in zip(v, var_list):
#         m.x[idx].value = float(val)

# def raw_objective(v):
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_residuals(v):
#     set_vector(v)
#     h1 = value(m.c1.body)
#     h2 = value(m.c2.body)
#     return np.array([h1, h2])

# def penalized_objective(v, rho=1e6):
#     f = raw_objective(v)
#     h = constraint_residuals(v)
#     return f + rho * np.sum(h**2)

# # ============================================================
# # 3. Initial guess (no bounds for NEWUOA)
# # ============================================================
# x0 = get_vector()

# # ============================================================
# # 4. Solve with NEWUOA via PDFO
# # ============================================================
# res = pdfo(
#     fun=lambda v: penalized_objective(v, rho=1e6),
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 20000,
#         'rhobeg': 1.0,
#         'rhoend': 1e-6,
#     }
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- NEWUOA (Penalty) Results ---")
# print(f"Success: {res.success}")
# print(f"Message: {res.message}")
# print(f"Objective (penalized): {res.fun:.6f}")
# print(f"Function evaluations : {res.nfev}")
# print(f"Solution x           : {res.x}")

# # Push solution back to Pyomo model
# set_vector(res.x)

# h = constraint_residuals(res.x)
# f_raw = raw_objective(res.x)

# print("\n--- Solution in Pyomo Model ---")
# for i in var_list:
#     print(f"x[{i}] = {value(m.x[i]):.6f}")

# print(f"Constraint residual h1(x): {h[0]:.6e}")
# print(f"Constraint residual h2(x): {h[1]:.6e}")
# print(f"Raw objective (unpenalized): {f_raw:.6f}")
# print(f"Penalty term (ρΣh²): {1e6 * np.sum(h**2):.6f}")





#P3

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import ConcreteModel, Var, Objective, Constraint, Reals, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Variables
# m.x1 = Var(initialize=0.0)
# m.x2 = Var(bounds=(-2.0, None), initialize=0.0)

# # Objective
# m.obj = Objective(expr=(m.x1 - 1)**2 + (m.x2 - 3)**2 + m.x1**2 + (m.x2**2)**2)

# # Equality constraint (handled via penalty)
# m.c1 = Constraint(expr=2*m.x1 + m.x2 + 10.0 - m.x1**2 - m.x2**2 == 0)


# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = [m.x1, m.x2]

# def get_vector():
#     """Extract NumPy vector of variable values."""
#     return np.array([value(v) for v in var_list])

# def set_vector(v):
#     """Assign NumPy vector values to Pyomo variables."""
#     for val, var in zip(v, var_list):
#         var.value = float(val)

# def raw_objective(v):
#     """Evaluate the original Pyomo objective."""
#     set_vector(v)
#     return value(m.obj.expr)

# def equality_constraint(v):
#     """Compute equality constraint residual h(x)."""
#     set_vector(v)
#     return value(m.c1.body)

# def penalized_objective(v, rho=1e6):
#     """Quadratic penalty formulation for equality constraint."""
#     f = raw_objective(v)
#     h = equality_constraint(v)
#     return f + rho * (h**2)


# # ============================================================
# # 3. Initial guess
# # ============================================================
# x0 = get_vector()


# # ============================================================
# # 4. Solve with NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=lambda v: penalized_objective(v, rho=1e6),
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 20000,
#         'rhobeg': 1.0,     # initial trust-region radius
#         'rhoend': 1e-6,    # final trust-region radius
#     }
# )


# # ============================================================
# # 5. Print results (benchmark-style)
# # ============================================================
# print("\n--- NEWUOA (Penalty) Results ---")
# print(f"Success: {res.success}")
# print(f"Message: {res.message}")
# print(f"Objective (penalized): {res.fun:.6f}")
# print(f"Function evaluations : {res.nfev}")
# print(f"Solution x           : {res.x}")

# # Push solution back into Pyomo
# set_vector(res.x)

# # Evaluate raw objective and constraint residual
# h = equality_constraint(res.x)
# f_raw = raw_objective(res.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x1):.6f}")
# print(f"x2 = {value(m.x2):.6f}")
# print(f"Constraint residual h(x): {h:.6e}")
# print(f"Raw objective (no penalty): {f_raw:.6f}")
# print(f"Penalty term (ρh²): {1e6 * h**2:.6f}")





#P4

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value, cos

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# n = 3  # Dimension of the Rastrigin function

# m = ConcreteModel()
# m.x = Var(range(n), domain=Reals, initialize=0.0, bounds=(-5.12, 5.12))

# # Objective: Rastrigin function
# # f(x) = 10*n + Σ [x_i^2 - 10*cos(2πx_i)]
# m.obj = Objective(expr=10*n + sum(m.x[i]**2 - 10*cos(2*(22/7)*m.x[i]) for i in range(n)))


# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Extract NumPy vector of variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Assign NumPy vector values back into the Pyomo model."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def objective(v):
#     """Objective function for NEWUOA."""
#     set_vector(v)
#     return value(m.obj.expr)


# # ============================================================
# # 3. Define initial point (no bounds for NEWUOA)
# # ============================================================
# x0 = get_vector()


# # ============================================================
# # 4. Solve with NEWUOA via PDFO
# # ============================================================
# res = pdfo(
#     fun=objective,
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 50000,   # allow more evaluations for multimodal function
#         'rhobeg': 1.0,     # initial trust-region radius
#         'rhoend': 1e-6,    # final trust-region radius
#     }
# )


# # ============================================================
# # 5. Print results (benchmark-style)
# # ============================================================
# print("\n--- NEWUOA Results ---")
# print(f"Success: {res.success}")
# print(f"Message: {res.message}")
# print(f"Objective: {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Solution x: {res.x}")

# # Push solution back into Pyomo
# set_vector(res.x)

# print("\n--- Solution in Pyomo Model ---")
# for i in range(n):
#     print(f"x[{i}] = {value(m.x[i]):.6f}")
# print(f"Objective value in Pyomo: {value(m.obj.expr):.6f}")




#P5

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import ConcreteModel, Var, Objective, Constraint, Reals, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()
# m.x = Var(range(4), domain=Reals, initialize=0.0, bounds=(-2, 2))

# # Constraints (Rosen–Suzuki)
# m.c1 = Constraint(expr=-(8 - m.x[0]**2 - m.x[1]**2 - m.x[2]**2 - m.x[3]**2 - m.x[0] + m.x[1] - m.x[2] + m.x[3]) <= 0)
# m.c2 = Constraint(expr=-(10 - m.x[0]**2 - 2*m.x[1]**2 - m.x[2]**2 - 2*m.x[3]**2 + m.x[0] + m.x[3]) <= 0)
# m.c3 = Constraint(expr=-(5 - 2*m.x[0]**2 - m.x[1]**2 - m.x[2]**2 - 2*m.x[0] + m.x[1] + m.x[3]) <= 0)

# # Objective function
# m.obj = Objective(
#     expr=(
#         m.x[0]**2 + m.x[1]**2 + m.x[3]**2
#         - 5*m.x[0] - 5*m.x[1]
#         + 2*m.x[2]**2 - 21*m.x[2] + 7*m.x[3]
#     )
# )


# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Extract NumPy vector of variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Assign NumPy vector values to Pyomo model."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def raw_objective(v):
#     """Compute original Pyomo objective."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_values(v):
#     """Return constraint residuals g(x) ≤ 0."""
#     set_vector(v)
#     return np.array([
#         value(m.c1.body),
#         value(m.c2.body),
#         value(m.c3.body)
#     ])

# def penalized_objective(v, rho=1e6):
#     """Quadratic penalty for constraint violations (g(x) > 0)."""
#     f = raw_objective(v)
#     g = constraint_values(v)
#     penalty = np.sum(np.maximum(g, 0)**2) * rho
#     return f + penalty


# # ============================================================
# # 3. Initial guess (unconstrained NEWUOA)
# # ============================================================
# x0 = get_vector()


# # ============================================================
# # 4. Solve with NEWUOA via PDFO
# # ============================================================
# res = pdfo(
#     fun=lambda v: penalized_objective(v, rho=1e6),
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 50000,   # allow more evals (nonlinear constraints)
#         'rhobeg': 1.0,
#         'rhoend': 1e-6
#     }
# )


# # ============================================================
# # 5. Print results (benchmark-style)
# # ============================================================
# print("\n--- NEWUOA (Penalty) Results ---")
# print(f"Success: {res.success}")
# print(f"Message: {res.message}")
# print(f"Objective (penalized): {res.fun:.6f}")
# print(f"Function evaluations : {res.nfev}")
# print(f"Solution x           : {res.x}")

# # Push back to Pyomo
# set_vector(res.x)

# # Compute residuals and raw objective
# f_raw = raw_objective(res.x)
# g_vals = constraint_values(res.x)

# print("\n--- Solution in Pyomo Model ---")
# for i in range(4):
#     print(f"x[{i}] = {value(m.x[i]):.6f}")
# print(f"Raw objective (no penalty): {f_raw:.6f}")
# print(f"Constraint values: {g_vals}")
# print(f"Total constraint violation penalty: {np.sum(np.maximum(g_vals, 0)**2) * 1e6:.6f}")




#P6

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import ConcreteModel, Var, Objective, Constraint, Reals, sin, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()
# m.x = Var(range(2), domain=Reals, initialize=0.5, bounds=(0, 1))

# # Constraints: g(x) ≤ 0
# m.c1 = Constraint(expr=1.5 - m.x[0] - 2*m.x[1] - 0.5*sin(-4*(22/7)*m.x[1] + 2*(22/7)*m.x[0]**2) <= 0)
# m.c2 = Constraint(expr=m.x[0]**2 + m.x[1]**2 - 1.5 <= 0)

# # Objective
# m.obj = Objective(expr=m.x[0] + m.x[1])


# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Extract NumPy vector of variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Assign NumPy vector values back into Pyomo model."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def raw_objective(v):
#     """Evaluate original Pyomo objective."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_values(v):
#     """Compute all constraint values g(x) ≤ 0."""
#     set_vector(v)
#     return np.array([
#         value(m.c1.body),
#         value(m.c2.body)
#     ])

# def penalized_objective(v, rho=1e6):
#     """Add quadratic penalties for violated constraints."""
#     f = raw_objective(v)
#     g = constraint_values(v)
#     return f + rho * np.sum(np.maximum(g, 0)**2)


# # ============================================================
# # 3. Initial guess
# # ============================================================
# x0 = get_vector()


# # ============================================================
# # 4. Solve with NEWUOA via PDFO
# # ============================================================
# res = pdfo(
#     fun=lambda v: penalized_objective(v, rho=1e6),
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 20000,
#         'rhobeg': 0.5,   # initial trust-region radius
#         'rhoend': 1e-6,  # final trust-region radius
#     }
# )


# # ============================================================
# # 5. Print results (benchmark-style)
# # ============================================================
# print("\n--- NEWUOA (Penalty) Results ---")
# print(f"Success: {res.success}")
# print(f"Message: {res.message}")
# print(f"Objective (penalized): {res.fun:.6f}")
# print(f"Function evaluations : {res.nfev}")
# print(f"Solution x           : {res.x}")

# # Push back into Pyomo model
# set_vector(res.x)

# # Evaluate raw objective and constraints
# f_raw = raw_objective(res.x)
# g_vals = constraint_values(res.x)

# print("\n--- Solution in Pyomo Model ---")
# for i in range(2):
#     print(f"x[{i}] = {value(m.x[i]):.6f}")
# print(f"Raw objective (no penalty): {f_raw:.6f}")
# print(f"Constraint values: {g_vals}")
# print(f"Total penalty (ρΣmax(g,0)²): {np.sum(np.maximum(g_vals, 0)**2) * 1e6:.6f}")



#P7

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Variables (bounded domain)
# m.x1 = Var(domain=Reals, initialize=0.0, bounds=(-2, 2))
# m.x2 = Var(domain=Reals, initialize=-1.0, bounds=(-2, 2))

# # Objective (Goldstein–Price function)
# m.obj = Objective(
#     expr=(
#         1 + (m.x1 + m.x2 + 1)**2
#           * (19 - 14*m.x1 + 3*m.x1**2 - 14*m.x2 + 6*m.x1*m.x2 + 3*m.x2**2)
#     ) * (
#         30 + (2*m.x1 - 3*m.x2)**2
#           * (18 - 32*m.x1 + 12*m.x1**2 + 48*m.x2 - 36*m.x1*m.x2 + 27*m.x2**2)
#     )
# )

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# def get_vector(model):
#     """Extract NumPy vector from Pyomo model."""
#     return np.array([value(model.x1), value(model.x2)])

# def set_vector(model, v):
#     """Set Pyomo variables from NumPy vector."""
#     model.x1.value = float(v[0])
#     model.x2.value = float(v[1])

# def objective(v):
#     """Objective callable for NEWUOA."""
#     set_vector(m, v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Define initial point (NEWUOA ignores bounds)
# # ============================================================
# x0 = get_vector(m)

# # ============================================================
# # 4. Solve with NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=objective,
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 30000,
#         'rhobeg': 1.0,
#         'rhoend': 1e-6
#     }
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- NEWUOA Results ---")
# print(f"Success: {res.success}")
# print(f"Message: {res.message}")
# print(f"Objective: {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Solution x: {res.x}")

# # Push solution back into Pyomo
# set_vector(m, res.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x1):.6f}")
# print(f"x2 = {value(m.x2):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")




#P8

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import ConcreteModel, Var, Objective, Constraint, Reals, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Decision variables
# m.x1 = Var(initialize=80, bounds=(78, 102))
# m.x2 = Var(initialize=35, bounds=(33, 45))
# m.x3 = Var(initialize=30, bounds=(27, 45))
# m.x4 = Var(initialize=30, bounds=(27, 45))
# m.x5 = Var(initialize=30, bounds=(27, 45))

# # Constraints (g(x) ≤ 0)
# m.c1 = Constraint(expr=0.00002584*m.x3*m.x5 - 0.00006663*m.x2*m.x5 - 0.0000734*m.x1*m.x4 - 1 <= 0)
# m.c2 = Constraint(expr=0.000853007*m.x2*m.x5 + 0.00009395*m.x1*m.x4 - 0.00033085*m.x3*m.x5 - 1 <= 0)
# m.c3 = Constraint(expr=1330.3294*((m.x2*m.x5)**(-1)) - 0.42*m.x1*((m.x5)**(-1)) - 0.30586*((m.x2*m.x5)**(-1))*m.x3**2 - 1 <= 0)
# m.c4 = Constraint(expr=0.00024186*m.x2*m.x5 + 0.00010159*m.x1*m.x2 + 0.00007379*m.x3**2 - 1 <= 0)
# m.c5 = Constraint(expr=2275.1327*((m.x3*m.x5)**(-1)) - 0.2668*m.x1*((m.x5)**(-1)) - 0.40584*((m.x5)**(-1))*m.x4 - 1 <= 0)
# m.c6 = Constraint(expr=0.00029955*m.x3*m.x5 + 0.00007992*m.x1*m.x2 + 0.00012157*m.x3*m.x4 - 1 <= 0)

# # Objective
# m.obj = Objective(expr=5.3578*m.x3**2 + 0.8357*m.x1*m.x5 + 37.2392*m.x1)

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = [m.x1, m.x2, m.x3, m.x4, m.x5]
# con_list = [m.c1, m.c2, m.c3, m.c4, m.c5, m.c6]

# def get_vector():
#     """Return NumPy vector of variable values."""
#     return np.array([value(v) for v in var_list])

# def set_vector(v):
#     """Assign NumPy vector values back into Pyomo model."""
#     for i, var in enumerate(var_list):
#         var.value = float(v[i])

# def raw_objective(v):
#     """Evaluate the Pyomo objective function."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_values(v):
#     """Return all g_i(x) values."""
#     set_vector(v)
#     return np.array([value(c.body) for c in con_list])

# def penalized_objective(v, rho=1e8):
#     """Objective + quadratic penalties for constraint violations."""
#     f = raw_objective(v)
#     g = constraint_values(v)
#     return f + rho * np.sum(np.maximum(g, 0)**2)


# # ============================================================
# # 3. Initial guess
# # ============================================================
# x0 = get_vector()

# # ============================================================
# # 4. Solve with NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=lambda v: penalized_objective(v, rho=1e8),
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 13100,
#         'rhobeg': 1.0,
#         'rhoend': 1e-6
#     }
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- NEWUOA (Penalty) Results ---")
# print(f"Success: {res.success}")
# print(f"Message: {res.message}")
# print(f"Objective (penalized): {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Solution x: {res.x}")

# # Push solution back into Pyomo model
# set_vector(res.x)

# # Evaluate raw objective and constraints
# f_raw = raw_objective(res.x)
# g_vals = constraint_values(res.x)

# print("\n--- Solution in Pyomo Model ---")
# for i, var in enumerate(var_list):
#     print(f"x[{i+1}] = {value(var):.6f}")
# print(f"Raw objective (no penalty): {f_raw:.6f}")
# print(f"Constraint values: {g_vals}")
# print(f"Total penalty: {np.sum(np.maximum(g_vals, 0)**2) * 1e8:.6f}")




#P10

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Decision variables
# m.x1 = Var(domain=Reals, initialize=3.0, bounds=(-4, 5))
# m.x2 = Var(domain=Reals, initialize=-0.256837, bounds=(-4, 5))
# m.x3 = Var(domain=Reals, initialize=0.517729, bounds=(-4, 5))
# m.x4 = Var(domain=Reals, initialize=2.244261, bounds=(-4, 5))

# # Objective (Powell singular function)
# m.obj = Objective(
#     expr=(m.x1 + 10*m.x2)**2
#         + 5*(m.x3 - m.x4)**2
#         + (m.x2 - 2*m.x3)**4
#         + 10*(m.x1 - m.x4)**4
# )

# # ============================================================
# # 2. Bridge Pyomo ↔ NumPy
# # ============================================================
# var_list = [m.x1, m.x2, m.x3, m.x4]

# def get_vector():
#     """Return NumPy vector of variable values."""
#     return np.array([value(v) for v in var_list])

# def set_vector(v):
#     """Assign NumPy vector values to Pyomo variables."""
#     for i, var in enumerate(var_list):
#         var.value = float(v[i])

# def objective(v):
#     """Objective evaluation for NEWUOA."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Initial point
# # ============================================================
# x0 = get_vector()

# # ============================================================
# # 4. Solve using NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=objective,
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 30000,
#         'rhobeg': 1.0,
#         'rhoend': 1e-6,
#         'quiet': False
#     }
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- NEWUOA Results ---")
# print(f"Success: {res.success}")
# print(f"Message: {res.message}")
# print(f"Objective: {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Solution x: {res.x}")

# # Push solution back into Pyomo model
# set_vector(res.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x1):.6f}")
# print(f"x2 = {value(m.x2):.6f}")
# print(f"x3 = {value(m.x3):.6f}")
# print(f"x4 = {value(m.x4):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")




#P11

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, sin, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Decision variable
# m.x = Var(domain=Reals, initialize=1.0, bounds=(0.5, 2.5))

# # Objective: f(x) = sin(10πx)/(2x) + (x − 1)^4
# m.obj = Objective(expr=sin(10*(22/7)*m.x)/(2*m.x) + (m.x - 1)**4)

# # ============================================================
# # 2. Bridge Pyomo ↔ NumPy
# # ============================================================
# def get_vector():
#     """Return NumPy vector of variable values."""
#     return np.array([value(m.x)])

# def set_vector(v):
#     """Assign NumPy vector back into the Pyomo model."""
#     m.x.value = float(v[0])

# def objective(v):
#     """Objective function evaluation for NEWUOA."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Initial guess and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([m.x.lb if m.x.lb is not None else -10.0])
# ub = np.array([m.x.ub if m.x.ub is not None else 10.0])
# bounds = list(zip(lb, ub))  # NEWUOA ignores bounds (unconstrained)

# # ============================================================
# # 4. Solve with NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=objective,
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 50000,
#         'rhobeg': 0.5,   # initial trust-region radius
#         'rhoend': 1e-6,  # final radius
#         'scale': True
#     }
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- NEWUOA Results ---")
# print(f"Success: {res.success}")
# print(f"Message: {res.message}")
# print(f"Objective: {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Solution x: {res.x}")

# # Push solution back into Pyomo model
# set_vector(res.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x = {value(m.x):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")



#P12

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value, cos, exp

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Two decision variables
# m.x = Var(range(2), domain=Reals, initialize=0.0, bounds=(-100, 100))

# # Objective: f(x) = -cos(x0)*cos(x1)*exp(-((x0 - π)^2 + (x1 - π)^2))
# m.obj = Objective(
#     expr = -cos(m.x[0]) * cos(m.x[1]) *
#            exp(-((m.x[0] - (22/7))**2 + (m.x[1] - (22/7))**2))
# )

# # ============================================================
# # 2. Bridge Pyomo ↔ NumPy
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Return NumPy vector of variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Assign NumPy vector values back to the Pyomo model."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def objective(v):
#     """Objective function for NEWUOA."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Initial guess and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([-100.0, -100.0])
# ub = np.array([100.0, 100.0])
# bounds = list(zip(lb, ub))  # NEWUOA ignores bounds (unconstrained)

# # ============================================================
# # 4. Solve using NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=objective,
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 50000,
#         'rhobeg': 1.0,      # initial trust-region radius
#         'rhoend': 1e-6,     # final radius
#         'scale': True,
#         'quiet': False
#     }
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- NEWUOA Results ---")
# print(f"Success: {res.success}")
# print(f"Message: {res.message}")
# print(f"Objective: {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Solution x: {res.x}")

# # Push back into Pyomo model
# set_vector(res.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x0 = {value(m.x[0]):.6f}")
# print(f"x1 = {value(m.x[1]):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")




#P13

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Decision variables
# m.x1 = Var(domain=Reals, initialize=0.1, bounds=(-3, 2))
# m.x2 = Var(domain=Reals, initialize=0.1, bounds=(-2, 2))

# # Objective: Six-Hump Camelback function
# # f(x1, x2) = 4x1² − 2.1x1⁴ + (x1⁶)/3 + x1x2 − 4x2² + 4x2⁴
# m.obj = Objective(
#     expr=4*m.x1**2 - 2.1*m.x1**4 + (m.x1**6)/3 + m.x1*m.x2 - 4*m.x2**2 + 4*m.x2**4
# )

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = [m.x1, m.x2]

# def get_vector():
#     """Extract NumPy vector of variable values."""
#     return np.array([value(v) for v in var_list])

# def set_vector(v):
#     """Assign NumPy vector values to Pyomo variables."""
#     for i, var in enumerate(var_list):
#         var.value = float(v[i])

# def objective(v):
#     """Objective callable for NEWUOA."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Initial point and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([v.lb for v in var_list])
# ub = np.array([v.ub for v in var_list])
# bounds = list(zip(lb, ub))  # NEWUOA ignores bounds (unconstrained)

# # ============================================================
# # 4. Solve using NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=objective,
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 50000,
#         'rhobeg': 0.5,    # initial trust-region radius
#         'rhoend': 1e-6,   # final trust-region radius
#         'scale': True,
#         'quiet': False
#     }
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- NEWUOA Results ---")
# print(f"Success: {res.success}")
# print(f"Message: {res.message}")
# print(f"Objective: {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Solution x: {res.x}")

# # Push solution back into Pyomo model
# set_vector(res.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x1):.6f}")
# print(f"x2 = {value(m.x2):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")



#P14

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Decision variables
# m.x = Var(range(2), domain=Reals, initialize=0.0, bounds=(-5, 5))

# # Objective: Three-Hump Camel function
# # f(x1, x2) = 2x1² - 1.05x1⁴ + (x1⁶)/6 + x1x2 + x2²
# m.obj = Objective(
#     expr = 2*(m.x[0]**2)
#          - 1.05*(m.x[0]**4)
#          + (m.x[0]**6)/6
#          + (m.x[0]*m.x[1])
#          + (m.x[1]**2)
# )

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Extract NumPy vector of current variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Assign NumPy vector values back to the Pyomo model."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def objective(v):
#     """Objective callable for NEWUOA."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Initial point and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([-5.0, -5.0])
# ub = np.array([ 5.0,  5.0])
# bounds = list(zip(lb, ub))  # NEWUOA ignores bounds (unconstrained)

# # ============================================================
# # 4. Solve using NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=objective,
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 50000,
#         'rhobeg': 1.0,    # initial trust-region radius
#         'rhoend': 1e-6,   # final radius
#         'scale': True,
#         'quiet': False
#     }
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- NEWUOA Results ---")
# print(f"Success: {res.success}")
# print(f"Message: {res.message}")
# print(f"Objective: {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Solution x: {res.x}")

# # Push solution back to Pyomo model
# set_vector(res.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")




#P15

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, sin, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Two decision variables with custom bounds
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds={0: (-1.5, 4.0), 1: (-3.0, 4.0)}
# )

# # Objective: f(x1, x2) = sin(x1 + x2) + (x1 − x2)² − 1.5x1 + 2.5x2 + 1
# m.obj = Objective(
#     expr = sin(m.x[0] + m.x[1])
#          + (m.x[0] - m.x[1])**2
#          - 1.5*m.x[0]
#          + 2.5*m.x[1]
#          + 1
# )

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Extract NumPy vector of variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Push NumPy vector values back into Pyomo model."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def objective(v):
#     """Objective callable for NEWUOA."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Initial guess and bounds (for reporting)
# # ============================================================
# x0 = get_vector()
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])
# bounds = list(zip(lb, ub))  # NEWUOA ignores bounds (unconstrained)

# # ============================================================
# # 4. Solve using NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=objective,
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 50000,
#         'rhobeg': 0.5,    # initial trust-region radius
#         'rhoend': 1e-6,   # final trust-region radius
#         'scale': True,
#         'quiet': False
#     }
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- NEWUOA Results ---")
# print(f"Success: {res.success}")
# print(f"Message: {res.message}")
# print(f"Objective: {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Solution x: {res.x}")

# # Push solution back into Pyomo model
# set_vector(res.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")




#P16

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Two decision variables with symmetric bounds
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-10, 10)
# )

# # Objective: Matyas function
# # f(x1, x2) = 0.26(x1² + x2²) − 0.48x1x2
# m.obj = Objective(
#     expr = 0.26*(m.x[0]**2 + m.x[1]**2) - 0.48*m.x[0]*m.x[1]
# )

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Extract NumPy vector of Pyomo variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Push NumPy vector values into Pyomo model."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def objective(v):
#     """Objective callable for NEWUOA."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Initial guess and bounds (for reference)
# # ============================================================
# x0 = get_vector()
# lb = np.array([-10.0, -10.0])
# ub = np.array([10.0, 10.0])
# bounds = list(zip(lb, ub))  # NEWUOA ignores bounds (unconstrained)

# # ============================================================
# # 4. Solve using NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=objective,
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 50000,
#         'rhobeg': 0.5,    # initial trust-region radius
#         'rhoend': 1e-6,   # final trust-region radius
#         'scale': True,
#         'quiet': False
#     }
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- NEWUOA Results ---")
# print(f"Success: {res.success}")
# print(f"Message: {res.message}")
# print(f"Objective: {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Solution x: {res.x}")

# # Push solution back to Pyomo model
# set_vector(res.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")




#P17
# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value, cos

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Two decision variables
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-100, 100)
# )

# # Objective:
# # f(x1, x2) = x1² + 2x2² - 0.3*cos(3πx1)*cos(4πx2) + 0.3
# m.obj = Objective(
#     expr = (m.x[0]**2)
#          + 2*(m.x[1]**2)
#          - 0.3*cos(3*(22/7)*m.x[0])*cos(4*(22/7)*m.x[1])
#          + 0.3
# )

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Extract NumPy vector of Pyomo variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Update Pyomo variables from NumPy vector."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def objective(v):
#     """Objective callable for NEWUOA."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Initial guess and bounds (for reference)
# # ============================================================
# x0 = get_vector()
# lb = np.array([-100.0, -100.0])
# ub = np.array([100.0, 100.0])
# bounds = list(zip(lb, ub))  # NEWUOA ignores bounds

# # ============================================================
# # 4. Solve using NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=objective,
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 50000,
#         'rhobeg': 1.0,    # initial trust-region radius
#         'rhoend': 1e-6,   # final trust-region radius
#         'scale': True,
#         'quiet': False
#     }
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- NEWUOA Results ---")
# print(f"Success: {res.success}")
# print(f"Message: {res.message}")
# print(f"Objective: {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Solution x: {res.x}")

# # Push solution back to Pyomo model
# set_vector(res.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")



#P18

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value, cos

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Two decision variables with bounds
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-100, 100)
# )

# # Objective:
# # f(x1, x2) = x1² + 2x2² − 0.3*cos(3πx1 + 4πx2) + 0.3
# m.obj = Objective(
#     expr = m.x[0]**2
#          + 2*m.x[1]**2
#          - 0.3*cos(3*(22/7)*m.x[0] + 4*(22/7)*m.x[1])
#          + 0.3
# )

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Extract NumPy vector of variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Push NumPy vector values into Pyomo model."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def objective(v):
#     """Objective callable for NEWUOA."""
#     set_vector(v)
#     return value(m.obj.expr)

# # ============================================================
# # 3. Initial guess and bounds (for record)
# # ============================================================
# x0 = get_vector()
# lb = np.array([-100.0, -100.0])
# ub = np.array([100.0, 100.0])
# bounds = list(zip(lb, ub))  # NEWUOA ignores bounds, included for completeness

# # ============================================================
# # 4. Solve using NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=objective,
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 50000,
#         'rhobeg': 1.0,     # initial trust region radius
#         'rhoend': 1e-6,    # final trust region radius
#         'scale': True,
#         'quiet': False
#     }
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- NEWUOA Results ---")
# print(f"Success: {res.success}")
# print(f"Message: {res.message}")
# print(f"Objective: {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Solution x: {res.x}")

# # Push result back to Pyomo model
# set_vector(res.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Objective (Pyomo): {value(m.obj.expr):.6f}")



#P19
# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Reals, value, minimize as pyo_minimize, cos
# )

# # ============================================================
# # 1. Define your black-box function
# # ============================================================
# def blackbox(v):
#     """
#     Black-box objective function f(x1, x2).
#     This could represent an external simulator or CFD code.
#     """
#     x1, x2 = v
#     return x1**2 + 2*x2**2 - 0.3*np.cos(3*np.pi*x1 + 4*np.pi*x2) + 0.3


# # ============================================================
# # 2. Define the Pyomo model (symbolic representation)
# # ============================================================
# m = ConcreteModel()

# # Decision variables
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-100, 100)
# )

# # Pyomo objective (for comparison only, not passed to solver)
# m.obj = Objective(
#     expr = m.x[0]**2 + 2*m.x[1]**2
#          - 0.3*cos(3*(22/7)*m.x[0] + 4*(22/7)*m.x[1])
#          + 0.3,
#     sense = pyo_minimize
# )

# # ============================================================
# # 3. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Return NumPy vector of current variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Push NumPy vector values into Pyomo model."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# # ============================================================
# # 4. Initial vector and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([-100.0, -100.0])
# ub = np.array([100.0, 100.0])
# bounds = list(zip(lb, ub))  # NEWUOA ignores bounds (unconstrained)

# # ============================================================
# # 5. Solve using NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=blackbox,
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 50000,
#         'rhobeg': 1.0,    # initial trust-region radius
#         'rhoend': 1e-6,   # final trust-region radius
#         'scale': True,
#         'quiet': False
#     }
# )

# # ============================================================
# # 6. Print results
# # ============================================================
# print("\n--- NEWUOA (Black-Box) Results ---")
# print(f"Success flag       : {res.success}")
# print(f"Message            : {res.message}")
# print(f"Objective value    : {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Best solution (x*) : {res.x}")

# # Push the solution back to the Pyomo model
# set_vector(res.x)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Objective (Pyomo)  : {value(m.obj.expr):.6f}")






#P20
# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize as pyo_minimize
# )

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-2, 2)
# )

# # Objective: Rosenbrock function
# m.obj = Objective(
#     expr=(1 - m.x[0])**2 + 100*(m.x[1] - m.x[0]**2)**2,
#     sense=pyo_minimize
# )

# # Constraints:
# # g1(x) = x1 + x2 - 1 ≤ 0
# # g2(x) = x1² + x2² - 1 ≤ 0
# m.con1 = Constraint(expr=m.x[0] + m.x[1] - 1 <= 0)
# m.con2 = Constraint(expr=m.x[0]**2 + m.x[1]**2 - 1 <= 0)

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Return NumPy vector of current variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Update model variables from NumPy vector."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def raw_objective(v):
#     """Evaluate the original Rosenbrock objective."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_violation(v):
#     """Compute inequality constraint violations (positive parts)."""
#     set_vector(v)
#     g1 = value(m.x[0] + m.x[1] - 1)
#     g2 = value(m.x[0]**2 + m.x[1]**2 - 1)
#     return np.maximum([g1, g2], 0.0)

# def penalized_objective(v, rho=1e4):
#     """Quadratic penalty formulation for constraint violations."""
#     f = raw_objective(v)
#     g_viols = constraint_violation(v)
#     return f + rho * np.sum(g_viols**2)

# # ============================================================
# # 3. Initial point and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([-2.0, -2.0])
# ub = np.array([ 2.0,  2.0])
# bounds = list(zip(lb, ub))  # For reference, ignored by NEWUOA

# # ============================================================
# # 4. Solve using NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=lambda v: penalized_objective(v, rho=1e4),
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 50000,
#         'rhobeg': 0.5,     # initial trust-region radius
#         'rhoend': 1e-6,    # final trust-region radius
#         'scale': True,
#         'quiet': False
#     }
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- NEWUOA (Penalty) Results ---")
# print(f"Success flag       : {res.success}")
# print(f"Message            : {res.message}")
# print(f"Penalized Objective: {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Best solution (x*) : {res.x}")

# # Push the solution back into Pyomo
# set_vector(res.x)

# # Evaluate final constraint info
# raw_f = raw_objective(res.x)
# g_viol = constraint_violation(res.x)
# total_violation = np.sum(g_viol)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Raw Objective f(x): {raw_f:.6f}")
# print(f"Total Constraint Violation: {total_violation:.2e}")

#P21

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize as pyo_minimize
# )

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Two decision variables
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-4.5, 4.5)
# )

# # Objective: Beale function
# # f(x1, x2) = (1.5 - x1 + x1*x2)² + (2.25 - x1 + x1*x2²)² + (2.625 - x1 + x1*x2³)²
# m.obj = Objective(
#     expr=(1.5 - m.x[0] + m.x[0]*m.x[1])**2
#        + (2.25 - m.x[0] + m.x[0]*m.x[1]**2)**2
#        + (2.625 - m.x[0] + m.x[0]*m.x[1]**3)**2,
#     sense=pyo_minimize
# )

# # Constraints:
# # g1(x) = x1 + x2 - 3 ≤ 0
# # g2(x) = x1² + x2² - 5 ≤ 0
# m.con1 = Constraint(expr=m.x[0] + m.x[1] - 3 <= 0)
# m.con2 = Constraint(expr=m.x[0]**2 + m.x[1]**2 - 5 <= 0)

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Return NumPy vector of current variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Update Pyomo variables from NumPy vector."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def raw_objective(v):
#     """Evaluate the original Beale objective."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_violation(v):
#     """Compute inequality constraint violations (positive parts)."""
#     set_vector(v)
#     g1 = value(m.x[0] + m.x[1] - 3)
#     g2 = value(m.x[0]**2 + m.x[1]**2 - 5)
#     return np.maximum([g1, g2], 0.0)

# def penalized_objective(v, rho=1e4):
#     """Quadratic penalty formulation for constraint violations."""
#     f = raw_objective(v)
#     g_viols = constraint_violation(v)
#     return f + rho * np.sum(g_viols**2)

# # ============================================================
# # 3. Initial point and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([-4.5, -4.5])
# ub = np.array([ 4.5,  4.5])
# bounds = list(zip(lb, ub))  # For reference, ignored by NEWUOA

# # ============================================================
# # 4. Solve using NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=lambda v: penalized_objective(v, rho=1e4),
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 50000,
#         'rhobeg': 0.5,     # Initial trust-region radius
#         'rhoend': 1e-6,    # Final trust-region radius
#         'scale': True,
#         'quiet': False
#     }
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- NEWUOA (Penalty) Results ---")
# print(f"Success flag        : {res.success}")
# print(f"Message             : {res.message}")
# print(f"Penalized Objective : {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Best solution (x*)  : {res.x}")

# # Push the solution back into Pyomo
# set_vector(res.x)

# # Evaluate final constraint info
# raw_f = raw_objective(res.x)
# g_viol = constraint_violation(res.x)
# total_violation = np.sum(g_viol)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Raw Objective f(x)  : {raw_f:.6f}")
# print(f"Total Constraint Violation: {total_violation:.2e}")



#P22

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize as pyo_minimize
# )

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Decision variables
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-10, 10)
# )

# # Objective: Booth function
# # f(x1, x2) = (x1 + 2x2 - 7)² + (2x1 + x2 - 5)²
# m.obj = Objective(
#     expr=(m.x[0] + 2*m.x[1] - 7)**2 + (2*m.x[0] + m.x[1] - 5)**2,
#     sense=pyo_minimize
# )

# # Constraints:
# # g1(x) = x1 + x2 - 10 ≤ 0
# # g2(x) = x1² + x2² - 50 ≤ 0
# m.con1 = Constraint(expr=m.x[0] + m.x[1] - 10 <= 0)
# m.con2 = Constraint(expr=m.x[0]**2 + m.x[1]**2 - 50 <= 0)

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Return NumPy vector of current variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Update Pyomo variables from NumPy vector."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def raw_objective(v):
#     """Evaluate Booth function objective."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_violation(v):
#     """Return positive constraint violations (g_i(x) > 0)."""
#     set_vector(v)
#     g1 = value(m.x[0] + m.x[1] - 10)
#     g2 = value(m.x[0]**2 + m.x[1]**2 - 50)
#     return np.maximum([g1, g2], 0.0)

# def penalized_objective(v, rho=1e4):
#     """Quadratic penalty formulation."""
#     f = raw_objective(v)
#     g_viol = constraint_violation(v)
#     return f + rho * np.sum(g_viol**2)

# # ============================================================
# # 3. Initial point and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([-10.0, -10.0])
# ub = np.array([10.0, 10.0])
# bounds = list(zip(lb, ub))  # For reference only; NEWUOA ignores bounds

# # ============================================================
# # 4. Solve using NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=lambda v: penalized_objective(v, rho=1e4),
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 50000,
#         'rhobeg': 0.5,    # initial trust-region radius
#         'rhoend': 1e-6,   # final trust-region radius
#         'scale': True,
#         'quiet': False
#     }
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- NEWUOA (Penalty) Results ---")
# print(f"Success flag        : {res.success}")
# print(f"Message             : {res.message}")
# print(f"Penalized Objective : {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Best solution (x*)  : {res.x}")

# # Push solution back into Pyomo
# set_vector(res.x)

# # Evaluate final results
# raw_f = raw_objective(res.x)
# viol = constraint_violation(res.x)
# total_violation = np.sum(viol)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Raw Objective f(x)  : {raw_f:.6f}")
# print(f"Total Constraint Violation: {total_violation:.2e}")



#P23
# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize as pyo_minimize
# )

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Two decision variables
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-5, 5)
# )

# # Objective:
# # f(x1, x2) = 0.5 * [ (x1⁴ − 16x1² + 5x1) + (x2⁴ − 16x2² + 5x2) ]
# m.obj = Objective(
#     expr=(
#         (m.x[0]**4 - 16*m.x[0]**2 + 5*m.x[0])
#       + (m.x[1]**4 - 16*m.x[1]**2 + 5*m.x[1])
#     ) / 2,
#     sense=pyo_minimize
# )

# # Constraints:
# # g1(x) = x1 + x2 - 10 ≤ 0
# # g2(x) = x1² + x2² - 50 ≤ 0
# m.con1 = Constraint(expr=m.x[0] + m.x[1] - 10 <= 0)
# m.con2 = Constraint(expr=m.x[0]**2 + m.x[1]**2 - 50 <= 0)

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Return NumPy vector of current variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Update Pyomo variables from NumPy vector."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def raw_objective(v):
#     """Evaluate the original Pyomo objective."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_violation(v):
#     """Compute inequality constraint violations (positive parts)."""
#     set_vector(v)
#     g1 = value(m.x[0] + m.x[1] - 10)
#     g2 = value(m.x[0]**2 + m.x[1]**2 - 50)
#     return np.maximum([g1, g2], 0.0)

# def penalized_objective(v, rho=1e4):
#     """Quadratic penalty formulation for constraint violations."""
#     f = raw_objective(v)
#     g_viol = constraint_violation(v)
#     return f + rho * np.sum(g_viol**2)

# # ============================================================
# # 3. Initial point and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([-5.0, -5.0])
# ub = np.array([ 5.0,  5.0])
# bounds = list(zip(lb, ub))  # for reference; NEWUOA ignores bounds

# # ============================================================
# # 4. Solve using NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=lambda v: penalized_objective(v, rho=1e4),
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 50000,
#         'rhobeg': 0.5,    # initial trust-region radius
#         'rhoend': 1e-6,   # final trust-region radius
#         'scale': True,
#         'quiet': False
#     }
# )

# # ============================================================
# # 5. Display results
# # ============================================================
# print("\n--- NEWUOA (Penalty) Results ---")
# print(f"Success flag        : {res.success}")
# print(f"Message             : {res.message}")
# print(f"Penalized Objective : {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Best solution (x*)  : {res.x}")

# # Push results back into Pyomo
# set_vector(res.x)

# # Evaluate objective and constraints
# raw_f = raw_objective(res.x)
# viol = constraint_violation(res.x)
# total_violation = np.sum(viol)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Raw Objective f(x)  : {raw_f:.6f}")
# print(f"Constraint Violation: {total_violation:.2e}")




#P24

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize as pyo_minimize
# )

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Decision variables (unbounded)
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0}
# )

# # Original: maximize (x1 - 1)² + x2²
# # Convert to minimization: minimize [ -((x1 - 1)² + x2²) ]
# m.obj = Objective(
#     expr= -((m.x[0] - 1)**2 + m.x[1]**2),
#     sense=pyo_minimize
# )

# # Constraints:
# # g1(x) = x1² + 6x2 - 36 ≤ 0
# # g2(x) = -4x1 + x2² - 2x2 ≤ 0
# m.con1 = Constraint(expr=m.x[0]**2 + 6*m.x[1] - 36 <= 0)
# m.con2 = Constraint(expr=-4*m.x[0] + m.x[1]**2 - 2*m.x[1] <= 0)

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Return NumPy vector of current variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Update Pyomo variables from NumPy vector."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def raw_objective(v):
#     """Evaluate the original Pyomo objective."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_violation(v):
#     """Compute positive constraint violations (g_i(x) > 0)."""
#     set_vector(v)
#     g1 = value(m.x[0]**2 + 6*m.x[1] - 36)
#     g2 = value(-4*m.x[0] + m.x[1]**2 - 2*m.x[1])
#     return np.maximum([g1, g2], 0.0)

# def penalized_objective(v, rho=1e4):
#     """Quadratic penalty formulation for constraints."""
#     f = raw_objective(v)
#     g_viol = constraint_violation(v)
#     return f + rho * np.sum(g_viol**2)

# # ============================================================
# # 3. Initial point and (implicit) bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([-100.0, -100.0])
# ub = np.array([100.0,  100.0])
# bounds = list(zip(lb, ub))  # For reference; NEWUOA ignores bounds

# # ============================================================
# # 4. Solve using NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=lambda v: penalized_objective(v, rho=1e4),
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 50000,
#         'rhobeg': 1.0,     # initial trust-region radius
#         'rhoend': 1e-6,    # final trust-region radius
#         'scale': True,
#         'quiet': False
#     }
# )

# # ============================================================
# # 5. Display results
# # ============================================================
# print("\n--- NEWUOA (Penalty) Results ---")
# print(f"Success flag        : {res.success}")
# print(f"Message             : {res.message}")
# print(f"Penalized Objective : {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Best solution (x*)  : {res.x}")

# # Push the result back into Pyomo
# set_vector(res.x)

# # Evaluate raw objective and constraint residuals
# raw_f = raw_objective(res.x)
# viol = constraint_violation(res.x)
# total_violation = np.sum(viol)

# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Raw Objective f(x)  : {raw_f:.6f}  (this is -maximization value)")
# print(f"Constraint Violation: {total_violation:.2e}")
# print(f"True Maximization Value = {-raw_f:.6f}")


#P25

# import numpy as np
# from pdfo import pdfo
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize as pyo_minimize
# )

# # ============================================================
# # 1. Define the Pyomo model
# # ============================================================
# m = ConcreteModel()

# # Two decision variables with bounds
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds={0: (0, None), 1: (0, 1.8)}
# )

# # Objective: maximize (2x1 - x1² + x2)
# # Convert to minimization: minimize [ - (2x1 - x1² + x2) ]
# m.obj = Objective(
#     expr=-(2*m.x[0] - m.x[0]**2 + m.x[1]),
#     sense=pyo_minimize
# )

# # Constraint: g1(x) = x1² + x2² - 4 ≤ 0
# m.con1 = Constraint(expr=m.x[0]**2 + m.x[1]**2 - 4 <= 0)

# # ============================================================
# # 2. Pyomo ↔ NumPy bridge
# # ============================================================
# var_list = list(m.x.keys())

# def get_vector():
#     """Extract NumPy vector of variable values."""
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(v):
#     """Update Pyomo variables with NumPy vector values."""
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def raw_objective(v):
#     """Compute Pyomo objective value."""
#     set_vector(v)
#     return value(m.obj.expr)

# def constraint_violation(v):
#     """Compute positive part of inequality constraint g(x) > 0."""
#     set_vector(v)
#     g1 = value(m.x[0]**2 + m.x[1]**2 - 4)
#     return max(g1, 0.0)

# def penalized_objective(v, rho=1e4):
#     """Quadratic penalty for constraint violation."""
#     f = raw_objective(v)
#     g_viol = constraint_violation(v)
#     return f + rho * (g_viol**2)

# # ============================================================
# # 3. Initial guess and bounds
# # ============================================================
# x0 = get_vector()
# lb = np.array([m.x[i].lb if m.x[i].lb is not None else -100.0 for i in var_list])
# ub = np.array([m.x[i].ub if m.x[i].ub is not None else 100.0 for i in var_list])
# bounds = list(zip(lb, ub))  # for reference only; NEWUOA ignores explicit bounds

# # ============================================================
# # 4. Solve using NEWUOA (via PDFO)
# # ============================================================
# res = pdfo(
#     fun=lambda v: penalized_objective(v, rho=1e4),
#     x0=x0,
#     method='newuoa',
#     options={
#         'maxfev': 20000,
#         'rhobeg': 0.5,
#         'rhoend': 1e-6,
#         'scale': True,
#         'quiet': False
#     }
# )

# # ============================================================
# # 5. Print results
# # ============================================================
# print("\n--- NEWUOA (Penalty) Results ---")
# print(f"Success flag        : {res.success}")
# print(f"Message             : {res.message}")
# print(f"Penalized Objective : {res.fun:.6f}")
# print(f"Function evaluations: {res.nfev}")
# print(f"Best solution (x*)  : {res.x}")

# # Push back into Pyomo
# set_vector(res.x)

# # Evaluate final information
# raw_f = raw_objective(res.x)
# viol = constraint_violation(res.x)
# print("\n--- Solution in Pyomo Model ---")
# print(f"x1 = {value(m.x[0]):.6f}")
# print(f"x2 = {value(m.x[1]):.6f}")
# print(f"Raw Objective f(x)  : {raw_f:.6f}  (negative of maximization)")
# print(f"Constraint Violation: {viol:.2e}")
# print(f"True Maximization Value = {-raw_f:.6f}")




#P25












