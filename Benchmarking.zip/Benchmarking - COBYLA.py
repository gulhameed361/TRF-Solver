# -*- coding: utf-8 -*-
"""
Created on Mon Nov  3 09:49:18 2025

@author: gh00616
"""

#P1

import numpy as np
import modopt as mo
from modopt import COBYLA
from pyomo.environ import ConcreteModel, Var, Reals, Objective, Constraint, value

# ---- 1. Define the Pyomo model ----
model = ConcreteModel()
model.x = Var(range(2), domain=Reals, initialize=0.0)

# Objective: minimize x0^2 + x1^2
model.obj = Objective(expr=model.x[0]**2 + model.x[1]**2)

# Equality constraint: x0^3 + x0^2 + 1 - x1 = 0
# COBYLA can't handle equalities, so we will write it as two inequalities.

# ---- 2. Bridge Pyomo <-> modopt ----
var_list = list(model.x.keys())

def get_vector(model):
    return np.array([value(model.x[i]) for i in var_list])

def set_vector(model, v):
    for i, idx in enumerate(var_list):
        model.x[idx].value = float(v[i])

def objective(v):
    set_vector(model, v)
    return value(model.obj.expr)

def constraint(v):
    set_vector(model, v)
    h = value(model.x[0]**3 + model.x[0]**2 + 1 - model.x[1])
    # Represent h(x)=0 as h(x)<=0 and -h(x)<=0
    return np.array([h, -h])

# ---- 3. Define COBYLA problem ----
x0 = get_vector(model)
cl = np.array([-np.inf, -np.inf])  # lower bounds
cu = np.array([0.0, 0.0])          # upper bounds

problem = mo.ProblemLite(x0=x0, obj=objective, con=constraint, cl=cl, cu=cu)

optimizer = COBYLA(
    problem,
    solver_options={'maxiter': 1000, 'catol': 1e-6, 'disp': True}
)

# ---- 4. Solve ----
optimizer.solve()
optimizer.print_results()



#P2

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import (
#     ConcreteModel, Var, Reals, Objective, Constraint, sin, sqrt, value
# )

# # 1. Define the Pyomo model
# m = ConcreteModel()

# # Decision variables
# m.x = Var(range(5), domain=Reals, initialize=2.0)
# m.x[4].value = 1.0  # initial guess for x4

# # Objective
# m.obj = Objective(
#     expr=(m.x[0] - 1.0)**2
#        + (m.x[0] - m.x[1])**2
#        + (m.x[2] - 1.0)**2
#        + (m.x[3] - 1.0)**4
#        + (m.x[4] - 1.0)**6
# )

# # Constraints (equalities → will be converted later)
# m.c1 = Constraint(expr = m.x[3]*m.x[0]**2 + sin(m.x[3] - m.x[4]) - 2*sqrt(2.0) == 0)
# m.c2 = Constraint(expr = m.x[2]**4 * m.x[1]**2 + m.x[1] - 8 - sqrt(2.0) == 0)

# # 2. Bridge Pyomo <-> modopt (COBYLA)
# var_list = list(m.x.keys())

# def get_vector(model):
#     """Return NumPy vector of current variable values."""
#     return np.array([value(model.x[i]) for i in var_list])

# def set_vector(model, v):
#     """Update Pyomo variables from NumPy vector."""
#     for i, idx in enumerate(var_list):
#         model.x[idx].value = float(v[i])

# def objective(v):
#     """Objective for COBYLA."""
#     set_vector(m, v)
#     return value(m.obj.expr)

# def constraint(v):
#     """Convert equalities into inequalities for COBYLA."""
#     set_vector(m, v)
#     h1 = value(m.x[3]*m.x[0]**2 + sin(m.x[3] - m.x[4]) - 2*sqrt(2.0))
#     h2 = value(m.x[2]**4 * m.x[1]**2 + m.x[1] - 8 - sqrt(2.0))
#     # Represent each equality as two inequalities (h ≤ 0 and -h ≤ 0)
#     return np.array([h1, -h1, h2, -h2])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([-np.inf]*len(x0))
# ub = np.array([ np.inf]*len(x0))

# # Inequality bounds for COBYLA
# cl = np.array([-np.inf, -np.inf, -np.inf, -np.inf])
# cu = np.array([0.0, 0.0, 0.0, 0.0])

# problem = mo.ProblemLite(
#     x0 = x0,
#     obj = objective,
#     con = constraint,
#     cl = cl,
#     cu = cu,
#     xl = lb,
#     xu = ub
# )

# optimizer = COBYLA(
#     problem,
#     solver_options = {
#         'maxiter': 3000,
#         'catol': 1e-6,
#         'disp': True
#     }
# )

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()


#P3

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import ConcreteModel, Var, Reals, Objective, Constraint, value

# # 1. Define the Pyomo model
# m = ConcreteModel()

# # Variables
# m.x1 = Var(initialize=0.0)
# m.x2 = Var(bounds=(-2.0, None), initialize=0.0)

# # Objective
# m.obj = Objective(expr=(m.x1 - 1)**2 + (m.x2 - 3)**2 + m.x1**2 + (m.x2**2)**2)

# # Nonlinear equality constraint (to be converted later)
# m.c1 = Constraint(expr=2*m.x1 + m.x2 + 10.0 - m.x1**2 - m.x2**2 == 0)

# # 2. Bridge Pyomo <-> modopt
# var_list = [m.x1, m.x2]

# def get_vector(model):
#     return np.array([value(v) for v in var_list])

# def set_vector(model, v):
#     for i, var in enumerate(var_list):
#         var.value = float(v[i])

# def objective(v):
#     set_vector(m, v)
#     return value(m.obj.expr)

# def constraint(v):
#     set_vector(m, v)
#     h = value(2*m.x1 + m.x2 + 10.0 - m.x1**2 - m.x2**2)
#     # Convert equality h(x) = 0 → inequalities h(x) ≤ 0 and -h(x) ≤ 0
#     return np.array([h, -h])

# # 3. Define COBYLA problem
# x0 = get_vector(m)

# # Lower/upper variable bounds
# lb = np.array([-np.inf if v.lb is None else v.lb for v in var_list])
# ub = np.array([ np.inf if v.ub is None else v.ub for v in var_list])

# # Inequality bounds for COBYLA
# cl = np.array([-np.inf, -np.inf])
# cu = np.array([0.0, 0.0])

# problem = mo.ProblemLite(
#     x0=x0,
#     obj=objective,
#     con=constraint,
#     cl=cl,
#     cu=cu,
#     xl=lb,
#     xu=ub
# )

# optimizer = COBYLA(
#     problem,
#     solver_options={
#         'maxiter': 2000,
#         'catol': 1e-6,
#         'disp': True
#     }
# )

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()


#P4

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value, cos


# # ---- 1. Define the Pyomo model ----
# n = 3  # dimension of the Rastrigin function

# m = ConcreteModel()
# m.x = Var(range(n), domain=Reals, initialize=0.0, bounds=(-5.12, 5.12))

# # Objective: Rastrigin function
# # f(x) = 10*n + Σ [x_i^2 - 10*cos(2πx_i)]
# m.obj = Objective(expr=10*n + sum(m.x[i]**2 - 10*cos(2*(22/7)*m.x[i]) for i in range(n)))

# # ---- 2. Bridge to modopt (COBYLA expects NumPy-based callable functions) ----
# var_list = list(m.x.keys())

# def get_vector(m):
#     return np.array([value(m.x[i]) for i in var_list])

# def set_vector(m, v):
#     for i, idx in enumerate(var_list):
#         m.x[idx].value = float(v[i])

# def objective(v):
#     set_vector(m, v)
#     return value(m.obj.expr)

# # No constraints for Rastrigin
# def constraint(v):
#     return np.array([])

# # ---- 3. Define COBYLA problem ----
# x0 = get_vector(m)
# lb = np.array([-5.12]*n)
# ub = np.array([ 5.12]*n)

# problem = mo.ProblemLite(x0=x0, obj=objective, xl=lb, xu=ub)
# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # ---- 4. Solve ----
# optimizer.solve()
# optimizer.print_results()

#P5

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import ConcreteModel, Var, Objective, Constraint, Reals, value

# # 1. Define the Pyomo model
# m = ConcreteModel()
# m.x = Var(range(4), domain=Reals, initialize=0.0, bounds=(-2, 2))

# # Constraints (≤ 0 form)
# m.c1 = Constraint(expr = -(8 - m.x[0]**2 - m.x[1]**2 - m.x[2]**2 - m.x[3]**2 - m.x[0] + m.x[1] - m.x[2] + m.x[3]) <= 0)
# m.c2 = Constraint(expr = -(10 - m.x[0]**2 - 2*m.x[1]**2 - m.x[2]**2 - 2*m.x[3]**2 + m.x[0] + m.x[3]) <= 0)
# m.c3 = Constraint(expr = -(5 - 2*m.x[0]**2 - m.x[1]**2 - m.x[2]**2 - 2*m.x[0] + m.x[1] + m.x[3]) <= 0)

# # Objective: Rosen–Suzuki
# m.obj = Objective(expr = (
#     m.x[0]**2 + m.x[1]**2 + m.x[3]**2
#     - 5*m.x[0] - 5*m.x[1]
#     + 2*m.x[2]**2 - 21*m.x[2] + 7*m.x[3]
# ))

# # 2. Bridge Pyomo → modopt (for COBYLA)
# var_list = list(m.x.keys())

# def get_vector(model):
#     """Extract NumPy vector of variable values."""
#     return np.array([value(model.x[i]) for i in var_list])

# def set_vector(model, v):
#     """Assign NumPy vector values back to Pyomo variables."""
#     for i, idx in enumerate(var_list):
#         model.x[idx].value = float(v[i])

# def objective(v):
#     set_vector(m, v)
#     return value(m.obj.expr)

# def constraint(v):
#     """Return nonlinear inequality constraints g(x) ≤ 0."""
#     set_vector(m, v)
#     return np.array([
#         value(m.c1.body),
#         value(m.c2.body),
#         value(m.c3.body)
#     ])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([-2.0]*4)
# ub = np.array([ 2.0]*4)
# cl = np.array([-np.inf, -np.inf, -np.inf])   # lower bounds (no lower constraint)
# cu = np.array([0.0, 0.0, 0.0])               # upper bounds g(x) ≤ 0

# problem = mo.ProblemLite(
#     x0=x0,
#     obj=objective,
#     con=constraint,
#     cl=cl,
#     cu=cu,
#     xl=lb,
#     xu=ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})


# # 4. Solve
# optimizer.solve()
# optimizer.print_results()

#P6

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import ConcreteModel, Var, Objective, Constraint, Reals, sin, value

# # 1. Define the Pyomo model
# m = ConcreteModel()
# m.x = Var(range(2), domain=Reals, initialize=0.0, bounds=(0, 1))

# # Constraints (≤ 0 form)
# m.c1 = Constraint(
#     expr=1.5 - m.x[0] - 2*m.x[1] - 0.5*sin(-4*(22/7)*m.x[1] + 2*(22/7)*m.x[0]**2) <= 0
# )
# m.c2 = Constraint(
#     expr=m.x[0]**2 + m.x[1]**2 - 1.5 <= 0
# )

# # Objective: minimize  x₀ + x₁
# m.obj = Objective(expr=sum(m.x[i] for i in range(2)))

# # 2. Bridge Pyomo → modopt
# var_list = list(m.x.keys())

# def get_vector(model):
#     return np.array([value(model.x[i]) for i in var_list])

# def set_vector(model, v):
#     for i, idx in enumerate(var_list):
#         model.x[idx].value = float(v[i])

# def objective(v):
#     set_vector(m, v)
#     return value(m.obj.expr)

# def constraint(v):
#     set_vector(m, v)
#     return np.array([
#         value(m.c1.body),
#         value(m.c2.body)
#     ])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([0.0, 0.0])
# ub = np.array([1.0, 1.0])
# cl = np.array([-np.inf, -np.inf])   # lower bounds (none)
# cu = np.array([0.0, 0.0])           # upper bounds g(x) ≤ 0

# problem = mo.ProblemLite(
#     x0=x0,
#     obj=objective,
#     con=constraint,
#     cl=cl,
#     cu=cu,
#     xl=lb,
#     xu=ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()

#P7

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value

# # 1. Define the Pyomo model
# m = ConcreteModel()

# # Decision variables
# m.x1 = Var(domain=Reals, initialize=0.0, bounds=(-2, 2))
# m.x2 = Var(domain=Reals, initialize=-1.0, bounds=(-2, 2))

# # Objective: Goldstein–Price function
# # f(x1,x2) = [1 + (x1 + x2 + 1)^2 * (19 - 14x1 + 3x1^2 - 14x2 + 6x1x2 + 3x2^2)]
# #            * [30 + (2x1 - 3x2)^2 * (18 - 32x1 + 12x1^2 + 48x2 - 36x1x2 + 27x2^2)]
# m.obj = Objective(
#     expr=(
#         (1 + (m.x1 + m.x2 + 1)**2
#          * (19 - 14*m.x1 + 3*m.x1**2 - 14*m.x2 + 6*m.x1*m.x2 + 3*m.x2**2))
#         * (30 + (2*m.x1 - 3*m.x2)**2
#          * (18 - 32*m.x1 + 12*m.x1**2 + 48*m.x2 - 36*m.x1*m.x2 + 27*m.x2**2))
#     )
# )

# # 2. Bridge Pyomo → modopt (COBYLA)
# def get_vector(model):
#     return np.array([value(model.x1), value(model.x2)])

# def set_vector(model, v):
#     model.x1.value = float(v[0])
#     model.x2.value = float(v[1])

# def objective(v):
#     set_vector(m, v)
#     return value(m.obj.expr)

# # No constraints
# def constraint(v):
#     return np.array([])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([-2.0, -2.0])
# ub = np.array([ 2.0,  2.0])

# problem = mo.ProblemLite(
#     x0=x0,
#     obj=objective,
#     xl=lb,
#     xu=ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()

#P8

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import ConcreteModel, Var, Objective, Constraint, Reals, value


# # 1. Define the Pyomo model
# m = ConcreteModel()

# # Decision variables with bounds and initial values
# m.x1 = Var(initialize=80, bounds=(78, 102))
# m.x2 = Var(initialize=35, bounds=(33, 45))
# m.x3 = Var(initialize=30, bounds=(27, 45))
# m.x4 = Var(initialize=30, bounds=(27, 45))
# m.x5 = Var(initialize=30, bounds=(27, 45))

# # Constraints (all ≤ 0 form)
# m.c1 = Constraint(expr=0.00002584*m.x3*m.x5 - 0.00006663*m.x2*m.x5 - 0.0000734*m.x1*m.x4 - 1 <= 0)
# m.c2 = Constraint(expr=0.000853007*m.x2*m.x5 + 0.00009395*m.x1*m.x4 - 0.00033085*m.x3*m.x5 - 1 <= 0)
# m.c3 = Constraint(expr=1330.3294*((m.x2*m.x5)**(-1)) - 0.42*m.x1*((m.x5)**(-1)) - 0.30586*((m.x2*m.x5)**(-1))*m.x3**2 - 1 <= 0)
# m.c4 = Constraint(expr=0.00024186*m.x2*m.x5 + 0.00010159*m.x1*m.x2 + 0.00007379*m.x3**2 - 1 <= 0)
# m.c5 = Constraint(expr=2275.1327*((m.x3*m.x5)**(-1)) - 0.2668*m.x1*((m.x5)**(-1)) - 0.40584*((m.x5)**(-1))*m.x4 - 1 <= 0)
# m.c6 = Constraint(expr=0.00029955*m.x3*m.x5 + 0.00007992*m.x1*m.x2 + 0.00012157*m.x3*m.x4 - 1 <= 0)

# # Objective (minimize)
# m.obj = Objective(expr=5.3578*m.x3**2 + 0.8357*m.x1*m.x5 + 37.2392*m.x1)

# # 2. Bridge Pyomo → modopt (COBYLA)
# var_list = [m.x1, m.x2, m.x3, m.x4, m.x5]
# con_list = [m.c1, m.c2, m.c3, m.c4, m.c5, m.c6]

# def get_vector(model):
#     return np.array([value(v) for v in var_list])

# def set_vector(model, v):
#     for i, var in enumerate(var_list):
#         var.value = float(v[i])

# def objective(v):
#     set_vector(m, v)
#     return value(m.obj.expr)

# def constraint(v):
#     set_vector(m, v)
#     return np.array([value(c.body) for c in con_list])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([v.lb for v in var_list], dtype=float)
# ub = np.array([v.ub for v in var_list], dtype=float)
# cl = np.full(len(con_list), -np.inf)  # lower bounds (none)
# cu = np.zeros(len(con_list))          # upper bounds g(x) ≤ 0

# problem = mo.ProblemLite(
#     x0=x0,
#     obj=objective,
#     con=constraint,
#     cl=cl,
#     cu=cu,
#     xl=lb,
#     xu=ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()

#P10

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value

# # 1. Define the Pyomo model
# m = ConcreteModel()

# # Decision variables (bounded but effectively free)
# m.x1 = Var(domain=Reals, initialize=3.0, bounds=(-4, 5))
# m.x2 = Var(domain=Reals, initialize=-0.256837, bounds=(-4, 5))
# m.x3 = Var(domain=Reals, initialize=0.517729, bounds=(-4, 5))
# m.x4 = Var(domain=Reals, initialize=2.244261, bounds=(-4, 5))

# # Objective function
# m.obj = Objective(
#     expr=(m.x1 + 10*m.x2)**2
#         + 5*(m.x3 - m.x4)**2
#         + (m.x2 - 2*m.x3)**4
#         + 10*(m.x1 - m.x4)**4
# )

# # 2. Bridge Pyomo → modopt (COBYLA)
# var_list = [m.x1, m.x2, m.x3, m.x4]

# def get_vector(model):
#     return np.array([value(v) for v in var_list])

# def set_vector(model, v):
#     for i, var in enumerate(var_list):
#         var.value = float(v[i])

# def objective(v):
#     set_vector(m, v)
#     return value(m.obj.expr)

# # No constraints in this problem
# def constraint(v):
#     return np.array([])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([v.lb for v in var_list])
# ub = np.array([v.ub for v in var_list])

# problem = mo.ProblemLite(
#     x0=x0,
#     obj=objective,
#     xl=lb,
#     xu=ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()

#P11

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, sin, value

# # 1. Define the Pyomo model
# m = ConcreteModel()

# # Single decision variable
# m.x = Var(domain=Reals, initialize=1.0, bounds=(0.5, 2.5))

# # Objective: f(x) = sin(10πx)/(2x) + (x − 1)^4
# m.obj = Objective(expr=sin(10*(22/7)*m.x)/(2*m.x) + (m.x - 1)**4)

# # 2. Bridge Pyomo → modopt (COBYLA)
# def get_vector(model):
#     return np.array([value(model.x)])

# def set_vector(model, v):
#     model.x.value = float(v[0])

# def objective(v):
#     set_vector(m, v)
#     return value(m.obj.expr)

# # No constraints
# def constraint(v):
#     return np.array([])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([m.x.lb])
# ub = np.array([m.x.ub])

# problem = mo.ProblemLite(
#     x0=x0,
#     obj=objective,
#     xl=lb,
#     xu=ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()

#P12

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value, cos, exp

# # 1. Define the Pyomo model
# m = ConcreteModel()
# m.x = Var(range(2), domain=Reals, initialize=0.0, bounds=(-100, 100))

# # Objective: f(x) = -cos(x₀)*cos(x₁)*exp(-(x₀ - π)² - (x₁ - π)²)
# m.obj = Objective(
#     expr = -cos(m.x[0]) * cos(m.x[1]) * exp(-((m.x[0] - (22/7))**2 + (m.x[1] - (22/7))**2))
# )

# # 2. Bridge Pyomo → modopt (COBYLA)
# var_list = list(m.x.keys())

# def get_vector(model):
#     return np.array([value(model.x[i]) for i in var_list])

# def set_vector(model, v):
#     for i, idx in enumerate(var_list):
#         model.x[idx].value = float(v[i])

# def objective(v):
#     set_vector(m, v)
#     return value(m.obj.expr)

# # No constraints
# def constraint(v):
#     return np.array([])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([-100.0, -100.0])
# ub = np.array([ 100.0,  100.0])

# problem = mo.ProblemLite(
#     x0=x0,
#     obj=objective,
#     xl=lb,
#     xu=ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()


#P13

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value

# # 1. Define the Pyomo model
# m = ConcreteModel()
# m.x1 = Var(domain=Reals, initialize=0.1, bounds=(-3, 2))
# m.x2 = Var(domain=Reals, initialize=0.1, bounds=(-2, 2))

# # Objective: Six-Hump Camelback Function
# # f(x1,x2) = 4x1² - 2.1x1⁴ + (x1⁶)/3 + x1x2 - 4x2² + 4x2⁴
# m.obj = Objective(
#     expr=4*m.x1**2 - 2.1*m.x1**4 + (m.x1**6)/3 + m.x1*m.x2 - 4*m.x2**2 + 4*m.x2**4
# )

# # 2. Bridge Pyomo → modopt (COBYLA)
# var_list = [m.x1, m.x2]

# def get_vector(model):
#     return np.array([value(v) for v in var_list])

# def set_vector(model, v):
#     for i, var in enumerate(var_list):
#         var.value = float(v[i])

# def objective(v):
#     set_vector(m, v)
#     return value(m.obj.expr)

# # No constraints in this problem
# def constraint(v):
#     return np.array([])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([v.lb for v in var_list])
# ub = np.array([v.ub for v in var_list])

# problem = mo.ProblemLite(
#     x0=x0,
#     obj=objective,
#     xl=lb,
#     xu=ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()

#P14

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value

# # 1. Define the Pyomo model
# m = ConcreteModel()
# m.x = Var(range(2), domain=Reals, initialize=0.0, bounds=(-5, 5))

# # Objective: Three-Hump Camel Function
# # f(x1,x2) = 2x1² - 1.05x1⁴ + (x1⁶)/6 + x1x2 + x2²
# m.obj = Objective(
#     expr = 2*(m.x[0]**2)
#          - 1.05*(m.x[0]**4)
#          + (m.x[0]**6)/6
#          + (m.x[0]*m.x[1])
#          + (m.x[1]**2)
# )

# # 2. Bridge Pyomo → modopt (COBYLA)
# var_list = list(m.x.keys())

# def get_vector(model):
#     return np.array([value(model.x[i]) for i in var_list])

# def set_vector(model, v):
#     for i, idx in enumerate(var_list):
#         model.x[idx].value = float(v[i])

# def objective(v):
#     set_vector(m, v)
#     return value(m.obj.expr)

# # No constraints
# def constraint(v):
#     return np.array([])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([-5.0, -5.0])
# ub = np.array([ 5.0,  5.0])

# problem = mo.ProblemLite(
#     x0=x0,
#     obj=objective,
#     xl=lb,
#     xu=ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()

#P15

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, sin, value

# # 1. Define the Pyomo model
# m = ConcreteModel()
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds={0: (-1.5, 4.0), 1: (-3.0, 4.0)}
# )

# # Objective:
# # f(x1,x2) = sin(x1 + x2) + (x1 - x2)² - 1.5x1 + 2.5x2 + 1
# m.obj = Objective(
#     expr = sin(m.x[0] + m.x[1])
#          + (m.x[0] - m.x[1])**2
#          - 1.5*m.x[0]
#          + 2.5*m.x[1]
#          + 1
# )

# # 2. Bridge Pyomo → modopt (COBYLA)
# var_list = list(m.x.keys())

# def get_vector(model):
#     """Return NumPy vector of current variable values."""
#     return np.array([value(model.x[i]) for i in var_list])

# def set_vector(model, v):
#     """Update model variables from a NumPy vector."""
#     for i, idx in enumerate(var_list):
#         model.x[idx].value = float(v[i])

# def objective(v):
#     """Objective function callable for COBYLA."""
#     set_vector(m, v)
#     return value(m.obj.expr)

# # No nonlinear constraints
# def constraint(v):
#     return np.array([])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])

# problem = mo.ProblemLite(
#     x0 = x0,
#     obj = objective,
#     xl = lb,
#     xu = ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()

#P16

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value

# # 1. Define the Pyomo model
# m = ConcreteModel()
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-10, 10)
# )

# # Objective: Matyas function
# # f(x1, x2) = 0.26*(x1² + x2²) - 0.48*x1*x2
# m.obj = Objective(
#     expr = 0.26*(m.x[0]**2 + m.x[1]**2) - 0.48*m.x[0]*m.x[1]
# )

# # 2. Bridge Pyomo → modopt (COBYLA)
# var_list = list(m.x.keys())

# def get_vector(model):
#     """Return NumPy vector of current variable values."""
#     return np.array([value(model.x[i]) for i in var_list])

# def set_vector(model, v):
#     """Update model variables from a NumPy vector."""
#     for i, idx in enumerate(var_list):
#         model.x[idx].value = float(v[i])

# def objective(v):
#     """Objective function callable for COBYLA."""
#     set_vector(m, v)
#     return value(m.obj.expr)

# # No constraints
# def constraint(v):
#     return np.array([])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])

# problem = mo.ProblemLite(
#     x0=x0,
#     obj=objective,
#     xl=lb,
#     xu=ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()

#P17
# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value, cos

# # 1. Define the Pyomo model
# m = ConcreteModel()
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-100, 100)
# )

# # Objective:
# # f(x1, x2) = x1² + 2x2² - 0.3*cos(3πx1)*cos(4πx2) + 0.3
# m.obj = Objective(
#     expr = (m.x[0]**2)
#          + 2*(m.x[1]**2)
#          - 0.3*cos(3*(22/7)*m.x[0])*cos(4*(22/7)*m.x[1])
#          + 0.3
# )

# # 2. Bridge Pyomo → modopt (COBYLA)
# var_list = list(m.x.keys())

# def get_vector(model):
#     """Return NumPy vector of current variable values."""
#     return np.array([value(model.x[i]) for i in var_list])

# def set_vector(model, v):
#     """Update model variables from NumPy vector."""
#     for i, idx in enumerate(var_list):
#         model.x[idx].value = float(v[i])

# def objective(v):
#     """Objective callable for COBYLA."""
#     set_vector(m, v)
#     return value(m.obj.expr)

# # No constraints
# def constraint(v):
#     return np.array([])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])

# problem = mo.ProblemLite(
#     x0 = x0,
#     obj = objective,
#     xl = lb,
#     xu = ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()

#P18

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import ConcreteModel, Var, Objective, Reals, value, cos

# # 1. Define the Pyomo model
# m = ConcreteModel()
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-100, 100)
# )

# # Objective:
# # f(x1, x2) = x1² + 2x2² - 0.3*cos(3πx1 + 4πx2) + 0.3
# m.obj = Objective(
#     expr = m.x[0]**2
#          + 2*m.x[1]**2
#          - 0.3*cos(3*(22/7)*m.x[0] + 4*(22/7)*m.x[1])
#          + 0.3
# )

# # 2. Bridge Pyomo → modopt (COBYLA)
# var_list = list(m.x.keys())

# def get_vector(model):
#     """Return NumPy vector of current variable values."""
#     return np.array([value(model.x[i]) for i in var_list])

# def set_vector(model, v):
#     """Update model variables from a NumPy vector."""
#     for i, idx in enumerate(var_list):
#         model.x[idx].value = float(v[i])

# def objective(v):
#     """Objective function callable for COBYLA."""
#     set_vector(m, v)
#     return value(m.obj.expr)

# # No constraints
# def constraint(v):
#     return np.array([])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])

# problem = mo.ProblemLite(
#     x0 = x0,
#     obj = objective,
#     xl = lb,
#     xu = ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()


#P19
# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Reals, value, minimize, cos
# )

# # 1. Define your black-box function
# def blackbox(v):
#     """
#     Black-box function f(x1, x2).
#     (This could be a simulation, CFD model, or external code.)
#     """
#     x1, x2 = v
#     return x1**2 + 2*x2**2 - 0.3*np.cos(3*np.pi*x1 + 4*np.pi*x2) + 0.3

# # 2. Define the Pyomo model (symbolic representation)
# m = ConcreteModel()

# # Two decision variables
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-100, 100)
# )

# # Objective (mirrors the black-box expression for clarity)
# m.obj = Objective(
#     expr = m.x[0]**2 + 2*m.x[1]**2
#          - 0.3*cos((3*(22/7)*m.x[0]) + (4*(22/7)*m.x[1])) + 0.3,
#     sense = minimize
# )

# # 3. Bridge Pyomo → modopt (COBYLA)
# var_list = list(m.x.keys())

# def get_vector(model):
#     """Return NumPy vector of current variable values."""
#     return np.array([value(model.x[i]) for i in var_list])

# def set_vector(model, v):
#     """Update model variables from NumPy vector."""
#     for i, idx in enumerate(var_list):
#         model.x[idx].value = float(v[i])

# def objective(v):
#     """Black-box objective callable for COBYLA."""
#     # you can either evaluate via Pyomo expression (value(m.obj.expr))
#     # or directly call the true blackbox function
#     return blackbox(v)

# def constraint(v):
#     """No constraints (unconstrained problem)."""
#     return np.array([])

# # 4. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])

# problem = mo.ProblemLite(
#     x0 = x0,
#     obj = objective,
#     xl = lb,
#     xu = ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 5. Solve
# optimizer.solve()
# optimizer.print_results()





#P20
# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize
# )

# # 1. Define the Pyomo model
# m = ConcreteModel()
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-2, 2)
# )

# # Objective: Rosenbrock with constraints
# # f(x1,x2) = (1 - x1)² + 100(x2 - x1²)²
# m.obj = Objective(
#     expr = (1 - m.x[0])**2 + 100*(m.x[1] - m.x[0]**2)**2,
#     sense = minimize
# )

# # Constraints:
# #  g1(x) = x1 + x2 - 1 ≤ 0
# #  g2(x) = x1² + x2² - 1 ≤ 0
# m.con1 = Constraint(expr = m.x[0] + m.x[1] - 1 <= 0)
# m.con2 = Constraint(expr = m.x[0]**2 + m.x[1]**2 - 1 <= 0)

# # 2. Bridge Pyomo → modopt (COBYLA)
# var_list = list(m.x.keys())
# con_list = [m.con1, m.con2]

# def get_vector(model):
#     """Return NumPy vector of current variable values."""
#     return np.array([value(model.x[i]) for i in var_list])

# def set_vector(model, v):
#     """Update model variables from a NumPy vector."""
#     for i, idx in enumerate(var_list):
#         model.x[idx].value = float(v[i])

# def objective(v):
#     """Objective function callable for COBYLA."""
#     set_vector(m, v)
#     return value(m.obj.expr)

# def constraint(v):
#     """Constraint function vector g(x) ≤ 0."""
#     set_vector(m, v)
#     g1 = value(m.x[0] + m.x[1] - 1)
#     g2 = value(m.x[0]**2 + m.x[1]**2 - 1)
#     return np.array([g1, g2])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])

# # Constraints: g(x) ≤ 0 → cl = [-∞, -∞], cu = [0, 0]
# cl = np.array([-np.inf, -np.inf])
# cu = np.array([0.0, 0.0])

# problem = mo.ProblemLite(
#     x0 = x0,
#     obj = objective,
#     con = constraint,
#     cl = cl,
#     cu = cu,
#     xl = lb,
#     xu = ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()

#P21

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize
# )

# # 1. Define the Pyomo model
# m = ConcreteModel()

# # Two decision variables
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-4.5, 4.5)
# )

# # Objective: Beale function
# # f(x1,x2) = (1.5 - x1 + x1*x2)² + (2.25 - x1 + x1*x2²)² + (2.625 - x1 + x1*x2³)²
# m.obj = Objective(
#     expr = (1.5 - m.x[0] + m.x[0]*m.x[1])**2
#          + (2.25 - m.x[0] + m.x[0]*m.x[1]**2)**2
#          + (2.625 - m.x[0] + m.x[0]*m.x[1]**3)**2,
#     sense = minimize
# )

# # Constraints:
# # g1(x) = x1 + x2 - 3 ≤ 0
# # g2(x) = x1² + x2² - 5 ≤ 0
# m.con1 = Constraint(expr = m.x[0] + m.x[1] - 3 <= 0)
# m.con2 = Constraint(expr = m.x[0]**2 + m.x[1]**2 - 5 <= 0)

# # 2. Bridge Pyomo → modopt (COBYLA)
# var_list = list(m.x.keys())

# def get_vector(model):
#     """Return NumPy vector of current variable values."""
#     return np.array([value(model.x[i]) for i in var_list])

# def set_vector(model, v):
#     """Update model variables from NumPy vector."""
#     for i, idx in enumerate(var_list):
#         model.x[idx].value = float(v[i])

# def objective(v):
#     """Objective function callable for COBYLA."""
#     set_vector(m, v)
#     return value(m.obj.expr)

# def constraint(v):
#     """Constraint vector g(x) ≤ 0."""
#     set_vector(m, v)
#     g1 = value(m.x[0] + m.x[1] - 3)
#     g2 = value(m.x[0]**2 + m.x[1]**2 - 5)
#     return np.array([g1, g2])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])

# # Inequality constraints g(x) ≤ 0 → cl = [-inf, -inf], cu = [0, 0]
# cl = np.array([-np.inf, -np.inf])
# cu = np.array([0.0, 0.0])

# problem = mo.ProblemLite(
#     x0 = x0,
#     obj = objective,
#     con = constraint,
#     cl = cl,
#     cu = cu,
#     xl = lb,
#     xu = ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()

#P22

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize
# )

# # 1. Define the Pyomo model
# m = ConcreteModel()

# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-10, 10)
# )

# # Objective: Booth function
# # f(x1,x2) = (x1 + 2x2 - 7)² + (2x1 + x2 - 5)²
# m.obj = Objective(
#     expr = (m.x[0] + 2*m.x[1] - 7)**2 + (2*m.x[0] + m.x[1] - 5)**2,
#     sense = minimize
# )

# # Constraints:
# # g1(x) = x1 + x2 - 10 ≤ 0
# # g2(x) = x1² + x2² - 50 ≤ 0
# m.con1 = Constraint(expr = m.x[0] + m.x[1] - 10 <= 0)
# m.con2 = Constraint(expr = m.x[0]**2 + m.x[1]**2 - 50 <= 0)

# # 2. Bridge Pyomo → modopt (COBYLA)
# var_list = list(m.x.keys())

# def get_vector(model):
#     """Return NumPy vector of current variable values."""
#     return np.array([value(model.x[i]) for i in var_list])

# def set_vector(model, v):
#     """Update model variables from NumPy vector."""
#     for i, idx in enumerate(var_list):
#         model.x[idx].value = float(v[i])

# def objective(v):
#     """Objective function callable for COBYLA."""
#     set_vector(m, v)
#     return value(m.obj.expr)

# def constraint(v):
#     """Constraint vector g(x) ≤ 0."""
#     set_vector(m, v)
#     g1 = value(m.x[0] + m.x[1] - 10)
#     g2 = value(m.x[0]**2 + m.x[1]**2 - 50)
#     return np.array([g1, g2])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])

# # Constraint bounds: g(x) ≤ 0
# cl = np.array([-np.inf, -np.inf])
# cu = np.array([0.0, 0.0])

# problem = mo.ProblemLite(
#     x0 = x0,
#     obj = objective,
#     con = constraint,
#     cl = cl,
#     cu = cu,
#     xl = lb,
#     xu = ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()

#P23
# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize
# )

# # 1. Define the Pyomo model
# m = ConcreteModel()

# # Two decision variables
# m.x = Var(
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0},
#     bounds=(-5, 5)
# )

# # Objective:
# # f(x1,x2) = 0.5 * [ (x1⁴ − 16x1² + 5x1) + (x2⁴ − 16x2² + 5x2) ]
# m.obj = Objective(
#     expr = (m.x[0]**4 - 16*m.x[0]**2 + 5*m.x[0]
#           + m.x[1]**4 - 16*m.x[1]**2 + 5*m.x[1]) / 2,
#     sense = minimize
# )

# # Constraints:
# # g1(x) = x1 + x2 - 10 ≤ 0
# # g2(x) = x1² + x2² - 50 ≤ 0
# m.con1 = Constraint(expr = m.x[0] + m.x[1] - 10 <= 0)
# m.con2 = Constraint(expr = m.x[0]**2 + m.x[1]**2 - 50 <= 0)

# # 2. Bridge Pyomo → modopt (COBYLA)
# var_list = list(m.x.keys())

# def get_vector(model):
#     """Return NumPy vector of current variable values."""
#     return np.array([value(model.x[i]) for i in var_list])

# def set_vector(model, v):
#     """Update model variables from a NumPy vector."""
#     for i, idx in enumerate(var_list):
#         model.x[idx].value = float(v[i])

# def objective(v):
#     """Objective function callable for COBYLA."""
#     set_vector(m, v)
#     return value(m.obj.expr)

# def constraint(v):
#     """Constraint vector g(x) ≤ 0."""
#     set_vector(m, v)
#     g1 = value(m.x[0] + m.x[1] - 10)
#     g2 = value(m.x[0]**2 + m.x[1]**2 - 50)
#     return np.array([g1, g2])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([m.x[i].lb for i in var_list])
# ub = np.array([m.x[i].ub for i in var_list])

# # Inequality constraints g(x) ≤ 0
# cl = np.array([-np.inf, -np.inf])
# cu = np.array([0.0, 0.0])

# problem = mo.ProblemLite(
#     x0 = x0,
#     obj = objective,
#     con = constraint,
#     cl = cl,
#     cu = cu,
#     xl = lb,
#     xu = ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()

#P24

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize
# )

# # 1. Define the Pyomo model
# m = ConcreteModel()

# # Two decision variables (unbounded)
# m.x = Var(s
#     range(2),
#     domain=Reals,
#     initialize={0: 0.0, 1: 0.0}
# )

# # Original problem: maximize (x1 - 1)^2 + x2^2
# # COBYLA minimizes, so we minimize the negative objective:
# m.obj = Objective(
#     expr = -((m.x[0] - 1)**2 + m.x[1]**2),
#     sense = minimize
# )

# # Constraints:
# # g1(x) = x1² + 6x2 - 36 ≤ 0
# # g2(x) = -4x1 + x2² - 2x2 ≤ 0
# m.con1 = Constraint(expr = m.x[0]**2 + 6*m.x[1] - 36 <= 0)
# m.con2 = Constraint(expr = -4*m.x[0] + m.x[1]**2 - 2*m.x[1] <= 0)

# # 2. Bridge Pyomo → modopt (COBYLA)
# var_list = list(m.x.keys())

# def get_vector(model):
#     """Return NumPy vector of current variable values."""
#     return np.array([value(model.x[i]) for i in var_list])

# def set_vector(model, v):
#     """Update model variables from NumPy vector."""
#     for i, idx in enumerate(var_list):
#         model.x[idx].value = float(v[i])

# def objective(v):
#     """Objective function callable for COBYLA."""
#     set_vector(m, v)
#     return value(m.obj.expr)

# def constraint(v):
#     """Constraint vector g(x) ≤ 0."""
#     set_vector(m, v)
#     g1 = value(m.x[0]**2 + 6*m.x[1] - 36)
#     g2 = value(-4*m.x[0] + m.x[1]**2 - 2*m.x[1])
#     return np.array([g1, g2])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([-np.inf, -np.inf])
# ub = np.array([ np.inf,  np.inf])

# # Constraint bounds: g(x) ≤ 0 → cl = [-inf, -inf], cu = [0, 0]
# cl = np.array([-np.inf, -np.inf])
# cu = np.array([0.0, 0.0])

# problem = mo.ProblemLite(
#     x0 = x0,
#     obj = objective,
#     con = constraint,
#     cl = cl,
#     cu = cu,
#     xl = lb,
#     xu = ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()

#P25

# import numpy as np
# import modopt as mo
# from modopt import COBYLA
# from pyomo.environ import (
#     ConcreteModel, Var, Objective, Constraint, Reals, value, minimize
# )

# # 1. Define the Pyomo model
# m = ConcreteModel()

# # Two decision variables with given bounds
# m.x = Var(
#     range(2),
#     bounds={0: (0, None), 1: (0, 1.8)},
#     initialize={0: 0.0, 1: 0.0}
# )

# # Original problem: maximize  2x1 - x1² + x2
# # COBYLA minimizes, so we minimize the negative objective:
# m.obj = Objective(
#     expr = -(2*m.x[0] - m.x[0]**2 + m.x[1]),
#     sense = minimize
# )

# # Constraint: x1² + x2² ≤ 4
# m.con1 = Constraint(expr = m.x[0]**2 + m.x[1]**2 - 4 <= 0)

# # 2. Bridge Pyomo → modopt (COBYLA)
# var_list = list(m.x.keys())

# def get_vector(model):
#     """Return NumPy vector of current variable values."""
#     return np.array([value(model.x[i]) for i in var_list])

# def set_vector(model, v):
#     """Update model variables from NumPy vector."""
#     for i, idx in enumerate(var_list):
#         model.x[idx].value = float(v[i])

# def objective(v):
#     """Objective function callable for COBYLA."""
#     set_vector(m, v)
#     return value(m.obj.expr)

# def constraint(v):
#     """Constraint vector g(x) ≤ 0."""
#     set_vector(m, v)
#     g1 = value(m.x[0]**2 + m.x[1]**2 - 4)
#     return np.array([g1])

# # 3. Define COBYLA problem
# x0 = get_vector(m)
# lb = np.array([m.x[i].lb if m.x[i].lb is not None else -np.inf for i in var_list])
# ub = np.array([m.x[i].ub if m.x[i].ub is not None else np.inf for i in var_list])

# # Constraint bounds: g(x) ≤ 0
# cl = np.array([-np.inf])
# cu = np.array([0.0])

# problem = mo.ProblemLite(
#     x0 = x0,
#     obj = objective,
#     con = constraint,
#     cl = cl,
#     cu = cu,
#     xl = lb,
#     xu = ub
# )

# optimizer = COBYLA(problem, solver_options={'maxiter': 2000, 'catol': 1e-6, 'disp': True})

# # 4. Solve
# optimizer.solve()
# optimizer.print_results()

#P25












